<?php
include('../auth/check.php');
include('../config/db.php');

$conn->query("
    CREATE TABLE IF NOT EXISTS system_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value VARCHAR(255) NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
");

$mode = $_POST['counter_assignment_mode'] ?? 'automatic';

if (!in_array($mode, ['automatic', 'manual'])) {
    $mode = 'automatic';
}

$stmt = $conn->prepare("
    INSERT INTO system_settings (setting_key, setting_value)
    VALUES ('counter_assignment_mode', ?)
    ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)
");

$stmt->bind_param("s", $mode);
$stmt->execute();

header("Location: ../staff/settings.php?saved=1");
exit;
?>