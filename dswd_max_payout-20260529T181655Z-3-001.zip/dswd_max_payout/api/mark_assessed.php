<?php
include('../auth/check.php');
include('../config/db.php');

date_default_timezone_set('Asia/Manila');

function redirectWithToast($redirect, $type, $message) {
    $allowedRedirects = [
        '../staff/assessment_screen.php',
        '../staff/confirmation_screen.php'
    ];

    if (!in_array($redirect, $allowedRedirects, true)) {
        $redirect = '../staff/assessment_screen.php';
    }

    $separator = strpos($redirect, '?') === false ? '?' : '&';

    header(
        'Location: ' . $redirect .
        $separator .
        'toast_type=' . urlencode($type) .
        '&toast_msg=' . urlencode($message)
    );
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirectWithToast('../staff/assessment_screen.php', 'error', 'Invalid request.');
}

$queue_id = intval($_POST['queue_id'] ?? 0);
$redirect = trim($_POST['redirect'] ?? '../staff/assessment_screen.php');

if ($queue_id <= 0) {
    redirectWithToast($redirect, 'error', 'Invalid queue selected.');
}

try {
    $check = $conn->prepare("
        SELECT 
            q.id,
            q.beneficiary_id,
            q.workflow_status
        FROM queue_entries q
        WHERE q.id = ?
        AND DATE(q.transaction_date) = CURDATE()
        LIMIT 1
    ");
    $check->bind_param('i', $queue_id);
    $check->execute();
    $result = $check->get_result();

    if (!$result || $result->num_rows === 0) {
        redirectWithToast($redirect, 'error', 'Queue not found.');
    }

    $queue = $result->fetch_assoc();

    if ($queue['workflow_status'] !== 'CALLED_STEP_2') {
        redirectWithToast($redirect, 'error', 'Only called assessment queues can be sent to confirmation.');
    }

    $formCheck = $conn->prepare("
        SELECT id
        FROM eligibility_forms
        WHERE queue_entry_id = ?
        AND form_locked = 1
        LIMIT 1
    ");
    $formCheck->bind_param('i', $queue_id);
    $formCheck->execute();
    $formResult = $formCheck->get_result();

    if (!$formResult || $formResult->num_rows === 0) {
        redirectWithToast($redirect, 'error', 'Please save/lock the GIS form first.');
    }

    $update = $conn->prepare("
        UPDATE queue_entries
        SET 
            workflow_status = 'WAITING_STEP_3',
            assessed_at = IFNULL(assessed_at, NOW()),
            counter_number = NULL,
            table_number = NULL
        WHERE id = ?
    ");
    $update->bind_param('i', $queue_id);
    $update->execute();

    redirectWithToast($redirect, 'success', 'Queue sent to confirmation successfully.');

} catch (Exception $e) {
    redirectWithToast($redirect, 'error', 'Failed to send queue to confirmation.');
}
?>