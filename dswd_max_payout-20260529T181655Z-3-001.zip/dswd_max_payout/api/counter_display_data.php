<?php
include('../auth/check.php');
include('../config/db.php');

header('Content-Type: application/json; charset=utf-8');

date_default_timezone_set('Asia/Manila');

function getRows($conn, $status, $section) {
    $stmt = $conn->prepare("
        SELECT 
            q.id,
            q.queue_number,
            q.counter_number,
            q.table_number,
            q.called_at,
            q.workflow_status
        FROM queue_entries q
        WHERE DATE(q.transaction_date)=CURDATE()
        AND q.workflow_status=?
        ORDER BY q.called_at DESC, q.id DESC
        LIMIT 8
    ");

    $stmt->bind_param('s', $status);
    $stmt->execute();
    $res = $stmt->get_result();

    $rows = [];

    while ($r = $res->fetch_assoc()) {
        $counter = intval($r['counter_number'] ?: $r['table_number'] ?: 0);

        $rows[] = [
            'id' => intval($r['id']),
            'queue_number' => $r['queue_number'],
            'counter_number' => $counter,
            'called_at' => $r['called_at'],
            'workflow_status' => $r['workflow_status'],
            'section' => $section
        ];
    }

    return $rows;
}

try {
    $assessment = getRows($conn, 'CALLED_STEP_2', 'assessment');
    $payout = getRows($conn, 'CALLED_STEP_3', 'payout');

    echo json_encode([
        'success' => true,
        'assessment' => $assessment,
        'payout' => $payout,
        'server_time' => date('h:i:s A')
    ]);
    exit;

} catch (Throwable $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'assessment' => [],
        'payout' => []
    ]);
    exit;
}
?>