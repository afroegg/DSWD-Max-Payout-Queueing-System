<?php
include('../auth/check.php');
include('../config/db.php');

header('Content-Type: application/json; charset=utf-8');

date_default_timezone_set('Asia/Manila');

ini_set('memory_limit', '1024M');
ini_set('max_execution_time', '600');
ini_set('max_input_time', '600');
ini_set('display_errors', 0);
error_reporting(E_ALL);

$autoload = __DIR__ . '/../vendor/autoload.php';

if (!file_exists($autoload)) {
    echo json_encode([
        'success' => false,
        'message' => 'Excel support is not installed. Run composer require phpoffice/phpspreadsheet'
    ]);
    exit;
}

require $autoload;

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

function clean($value) {
    return trim((string)$value);
}

function normalizeHeader($value) {
    $value = strtolower(trim((string)$value));
    $value = str_replace([' ', '-', '.', '/', '\\'], '_', $value);
    $value = preg_replace('/[^a-z0-9_]/', '', $value);
    $value = preg_replace('/_+/', '_', $value);
    return trim($value, '_');
}

function normalizeContact($value) {
    $value = trim((string)$value);

    if ($value === '') {
        return '';
    }

    $value = preg_replace('/[^0-9+]/', '', $value);

    if (preg_match('/^09\d{9}$/', $value)) {
        return $value;
    }

    if (preg_match('/^\+639\d{9}$/', $value)) {
        return $value;
    }

    if (preg_match('/^639\d{9}$/', $value)) {
        return '+' . $value;
    }

    return '';
}

function contactVariants($value) {
    $value = normalizeContact($value);

    if ($value === '') {
        return [];
    }

    if (preg_match('/^09\d{9}$/', $value)) {
        return [
            $value,
            '+63' . substr($value, 1),
            '63' . substr($value, 1)
        ];
    }

    if (preg_match('/^\+639\d{9}$/', $value)) {
        return [
            $value,
            '0' . substr($value, 3),
            substr($value, 1)
        ];
    }

    return [$value];
}

function normalizeHousehold($value) {
    $value = strtoupper(trim((string)$value));

    if ($value === '') {
        return '';
    }

    if (preg_match('/^HH-\d{10}$/', $value)) {
        return $value;
    }

    $digits = preg_replace('/\D/', '', $value);

    if ($digits === '') {
        return '';
    }

    if (strlen($digits) > 10) {
        $digits = substr($digits, 0, 10);
    }

    return 'HH-' . str_pad($digits, 10, '0', STR_PAD_LEFT);
}

function yesNoToInt($value) {
    $value = strtolower(trim((string)$value));

    return in_array($value, [
        'yes',
        'y',
        '1',
        'true',
        'oo',
        'pwd',
        'pregnant',
        'senior'
    ], true) ? 1 : 0;
}

function getValue($row, $headers, $names, $default = '') {
    foreach ($names as $name) {
        $key = normalizeHeader($name);

        if (isset($headers[$key])) {
            $index = $headers[$key];
            return isset($row[$index]) ? clean($row[$index]) : $default;
        }
    }

    return $default;
}

function parseBirthday($value, &$month, &$day, &$year) {
    $month = 0;
    $day = 0;
    $year = 0;

    if ($value === null || $value === '') {
        return false;
    }

    if (is_numeric($value)) {
        try {
            $date = ExcelDate::excelToDateTimeObject(floatval($value));
            $month = intval($date->format('m'));
            $day = intval($date->format('d'));
            $year = intval($date->format('Y'));
            return checkdate($month, $day, $year);
        } catch (Throwable $e) {
            return false;
        }
    }

    $value = trim((string)$value);

    $formats = [
        'm/d/Y',
        'Y-m-d',
        'd/m/Y',
        'm-d-Y',
        'Y/m/d',
        'F d, Y',
        'M d, Y'
    ];

    foreach ($formats as $format) {
        $date = DateTime::createFromFormat($format, $value);

        if ($date) {
            $month = intval($date->format('m'));
            $day = intval($date->format('d'));
            $year = intval($date->format('Y'));

            if (checkdate($month, $day, $year)) {
                return true;
            }
        }
    }

    $time = strtotime($value);

    if ($time !== false) {
        $month = intval(date('m', $time));
        $day = intval(date('d', $time));
        $year = intval(date('Y', $time));
        return checkdate($month, $day, $year);
    }

    return false;
}

function calculateAge($month, $day, $year) {
    if (!checkdate($month, $day, $year)) {
        return 0;
    }

    $birth = new DateTime("$year-$month-$day");
    $today = new DateTime();

    return intval($today->diff($birth)->y);
}

function preloadDuplicates($conn) {
    $data = [
        'contacts' => [],
        'households' => [],
        'identity' => []
    ];

    $res = $conn->query("
        SELECT 
            first_name,
            last_name,
            birthday_month,
            birthday_day,
            birthday_year,
            contact_number,
            household_id
        FROM beneficiaries
    ");

    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $contact = normalizeContact($r['contact_number'] ?? '');

            if ($contact !== '') {
                foreach (contactVariants($contact) as $variant) {
                    $data['contacts'][$variant] = true;
                }
            }

            $household = normalizeHousehold($r['household_id'] ?? '');

            if ($household !== '') {
                $data['households'][$household] = true;
            }

            $identityKey =
                strtolower(trim($r['first_name'] ?? '')) . '|' .
                strtolower(trim($r['last_name'] ?? '')) . '|' .
                intval($r['birthday_month'] ?? 0) . '|' .
                intval($r['birthday_day'] ?? 0) . '|' .
                intval($r['birthday_year'] ?? 0);

            $data['identity'][$identityKey] = true;
        }
    }

    return $data;
}

function getNextCodeStart($conn, $prefix = 'BEN') {
    $like = $prefix . '-%';
    $start = strlen($prefix) + 2;

    $stmt = $conn->prepare("
        SELECT MAX(CAST(SUBSTRING(beneficiary_code, ?) AS UNSIGNED)) AS last_number
        FROM beneficiaries
        WHERE beneficiary_code LIKE ?
    ");

    $stmt->bind_param('is', $start, $like);
    $stmt->execute();

    $res = $stmt->get_result();
    $next = 1;

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();

        if ($row['last_number'] !== null) {
            $next = intval($row['last_number']) + 1;
        }
    }

    return $next;
}

function makeBeneficiaryCode($prefix, $number) {
    return $prefix . '-' . str_pad($number, 5, '0', STR_PAD_LEFT);
}

function failJson($message) {
    echo json_encode([
        'success' => false,
        'message' => $message,
        'inserted' => 0,
        'duplicates' => 0,
        'failed' => 0,
        'checked' => 0,
        'errors' => []
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    failJson('Invalid request.');
}

if (!isset($_FILES['import_file'])) {
    failJson('No file uploaded.');
}

$file = $_FILES['import_file'];

if ($file['error'] !== UPLOAD_ERR_OK) {
    failJson('Upload failed.');
}

$maxSize = 80 * 1024 * 1024;

if ($file['size'] > $maxSize) {
    failJson('File too large. Maximum is 80MB.');
}

$originalName = $file['name'];
$ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

$allowed = ['csv', 'xlsx', 'xls', 'xlsm', 'ods'];

if (!in_array($ext, $allowed, true)) {
    failJson('Unsupported file. Upload CSV or Excel file: .csv, .xlsx, .xls, .xlsm, .ods');
}

try {
    $reader = IOFactory::createReaderForFile($file['tmp_name']);
    $reader->setReadDataOnly(true);

    $spreadsheet = $reader->load($file['tmp_name']);
    $sheet = $spreadsheet->getActiveSheet();

    $highestRow = $sheet->getHighestDataRow();
    $highestColumn = $sheet->getHighestDataColumn();

    if ($highestRow < 2) {
        failJson('File has no data rows.');
    }

    $rows = $sheet->rangeToArray(
        'A1:' . $highestColumn . $highestRow,
        null,
        true,
        false,
        false
    );

    if (count($rows) < 2) {
        failJson('File has no importable rows.');
    }

    $headerRow = $rows[0];
    $headers = [];

    foreach ($headerRow as $index => $headerName) {
        $key = normalizeHeader($headerName);

        if ($key !== '') {
            $headers[$key] = $index;
        }
    }

    if (!isset($headers['first_name']) && !isset($headers['firstname']) && !isset($headers['given_name'])) {
        failJson('Missing required header: first_name');
    }

    if (!isset($headers['last_name']) && !isset($headers['lastname']) && !isset($headers['surname'])) {
        failJson('Missing required header: last_name');
    }

    $duplicates = preloadDuplicates($conn);

    $inserted = 0;
    $duplicateCount = 0;
    $failed = 0;
    $checked = 0;
    $errors = [];

    $codeCounter = getNextCodeStart($conn, 'BEN');

    $insertStmt = $conn->prepare("
        INSERT INTO beneficiaries (
            beneficiary_code,
            first_name,
            middle_name,
            last_name,
            ext_name,
            contact_number,
            birthday_month,
            birthday_day,
            birthday_year,
            age,
            sex,
            lgu,
            national_id,
            household_id,
            program_type,
            region,
            province,
            city_municipality,
            barangay,
            sms_opt_in,
            is_pregnant
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    if (!$insertStmt) {
        failJson('Prepare failed: ' . $conn->error);
    }

    $conn->begin_transaction();

    for ($i = 1; $i < count($rows); $i++) {
        $rowNum = $i + 1;
        $row = $rows[$i];
        $checked++;

        $isEmpty = true;

        foreach ($row as $cell) {
            if (trim((string)$cell) !== '') {
                $isEmpty = false;
                break;
            }
        }

        if ($isEmpty) {
            continue;
        }

        $first_name = getValue($row, $headers, ['first_name', 'firstname', 'given_name']);
        $middle_name = getValue($row, $headers, ['middle_name', 'middlename', 'middle']);
        $last_name = getValue($row, $headers, ['last_name', 'lastname', 'surname', 'family_name']);
        $ext_name = getValue($row, $headers, ['ext_name', 'extension', 'suffix'], '');

        $contact_number = normalizeContact(getValue($row, $headers, ['contact_number', 'contact', 'mobile', 'phone'], ''));

        $sex = ucfirst(strtolower(getValue($row, $headers, ['sex', 'gender'], '')));

        $region = getValue($row, $headers, ['region'], 'MIMAROPA Region');
        $province = getValue($row, $headers, ['province'], '');
        $city_municipality = getValue($row, $headers, ['city_municipality', 'city', 'municipality'], '');
        $barangay = getValue($row, $headers, ['barangay', 'brgy'], '');
        $lgu = getValue($row, $headers, ['lgu'], '');

        if ($lgu === '') {
            $lgu = $city_municipality;
        }

        $national_id = getValue($row, $headers, ['national_id', 'id_presented', 'id'], '');
        $household_id = normalizeHousehold(getValue($row, $headers, ['household_id', 'hh_id', 'household'], ''));

        $program_type = getValue($row, $headers, ['program_type', 'assistance_type', 'assistance', 'category'], 'For Verification');

        $is_pwd = yesNoToInt(getValue($row, $headers, ['pwd', 'is_pwd', 'sms_opt_in'], 'No'));
        $is_pregnant = yesNoToInt(getValue($row, $headers, ['pregnant', 'is_pregnant'], 'No'));

        if ($sex !== 'Female') {
            $is_pregnant = 0;
        }

        $birthday_month = intval(getValue($row, $headers, ['birthday_month', 'birth_month'], 0));
        $birthday_day = intval(getValue($row, $headers, ['birthday_day', 'birth_day'], 0));
        $birthday_year = intval(getValue($row, $headers, ['birthday_year', 'birth_year'], 0));

        $birthdayValue = getValue($row, $headers, ['birthday', 'birthdate', 'date_of_birth', 'dob'], '');

        if ($birthdayValue !== '') {
            parseBirthday($birthdayValue, $birthday_month, $birthday_day, $birthday_year);
        }

        $age = intval(getValue($row, $headers, ['age'], 0));

        if ($age <= 0 && $birthday_month > 0 && $birthday_day > 0 && $birthday_year > 0) {
            $age = calculateAge($birthday_month, $birthday_day, $birthday_year);
        }

        if ($first_name === '' || $last_name === '') {
            $failed++;
            if (count($errors) < 40) {
                $errors[] = "Row $rowNum skipped: missing first name or last name.";
            }
            continue;
        }

        if (!in_array($sex, ['Male', 'Female'], true)) {
            $failed++;
            if (count($errors) < 40) {
                $errors[] = "Row $rowNum skipped: invalid sex.";
            }
            continue;
        }

        if ($birthday_month <= 0 || $birthday_day <= 0 || $birthday_year <= 0 || !checkdate($birthday_month, $birthday_day, $birthday_year)) {
            $failed++;
            if (count($errors) < 40) {
                $errors[] = "Row $rowNum skipped: invalid birthday.";
            }
            continue;
        }

        $identityKey =
            strtolower($first_name) . '|' .
            strtolower($last_name) . '|' .
            $birthday_month . '|' .
            $birthday_day . '|' .
            $birthday_year;

        $isDuplicate = false;

        if ($contact_number !== '') {
            foreach (contactVariants($contact_number) as $variant) {
                if (isset($duplicates['contacts'][$variant])) {
                    $isDuplicate = true;
                    break;
                }
            }
        }

        if (!$isDuplicate && $household_id !== '' && isset($duplicates['households'][$household_id])) {
            $isDuplicate = true;
        }

        if (!$isDuplicate && isset($duplicates['identity'][$identityKey])) {
            $isDuplicate = true;
        }

        if ($isDuplicate) {
            $duplicateCount++;
            continue;
        }

        $beneficiary_code = makeBeneficiaryCode('BEN', $codeCounter);
        $codeCounter++;

        $insertStmt->bind_param(
            'ssssssiiiisssssssssii',
            $beneficiary_code,
            $first_name,
            $middle_name,
            $last_name,
            $ext_name,
            $contact_number,
            $birthday_month,
            $birthday_day,
            $birthday_year,
            $age,
            $sex,
            $lgu,
            $national_id,
            $household_id,
            $program_type,
            $region,
            $province,
            $city_municipality,
            $barangay,
            $is_pwd,
            $is_pregnant
        );

        if ($insertStmt->execute()) {
            $inserted++;

            if ($contact_number !== '') {
                foreach (contactVariants($contact_number) as $variant) {
                    $duplicates['contacts'][$variant] = true;
                }
            }

            if ($household_id !== '') {
                $duplicates['households'][$household_id] = true;
            }

            $duplicates['identity'][$identityKey] = true;

            if ($inserted % 500 === 0) {
                $conn->commit();
                $conn->begin_transaction();
            }
        } else {
            $failed++;
            if (count($errors) < 40) {
                $errors[] = "Row $rowNum failed: " . $insertStmt->error;
            }
        }
    }

    $conn->commit();

    $spreadsheet->disconnectWorksheets();
    unset($spreadsheet);
    unset($rows);

    echo json_encode([
        'success' => true,
        'message' => 'Import completed.',
        'inserted' => $inserted,
        'duplicates' => $duplicateCount,
        'failed' => $failed,
        'checked' => $checked,
        'errors' => $errors
    ]);
    exit;

} catch (Throwable $e) {
    try {
        $conn->rollback();
    } catch (Throwable $rollbackError) {}

    echo json_encode([
        'success' => false,
        'message' => 'Import failed: ' . $e->getMessage(),
        'inserted' => 0,
        'duplicates' => 0,
        'failed' => 0,
        'checked' => 0,
        'errors' => []
    ]);
    exit;
}
?>