<?php
include('../config/db.php');

date_default_timezone_set('Asia/Manila');

function backHome($params = '') {
    header('Location: ../kiosk/index.php' . $params);
    exit;
}

function nextQueueNumber($conn, $prefix) {
    $like = $prefix . '-%';
    $start = strlen($prefix) + 2;

    $stmt = $conn->prepare("
        SELECT MAX(CAST(SUBSTRING(queue_number, ?) AS UNSIGNED)) AS last_number
        FROM queue_entries
        WHERE DATE(transaction_date) = CURDATE()
        AND queue_number LIKE ?
    ");

    $stmt->bind_param('is', $start, $like);
    $stmt->execute();
    $res = $stmt->get_result();

    $next = 1;

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();

        if ($row['last_number'] !== null) {
            $next = intval($row['last_number']) + 1;
        }
    }

    return $prefix . '-' . str_pad($next, 5, '0', STR_PAD_LEFT);
}

function nextBeneficiaryCode($conn, $prefix) {
    $like = $prefix . '-%';
    $start = strlen($prefix) + 2;

    $stmt = $conn->prepare("
        SELECT MAX(CAST(SUBSTRING(beneficiary_code, ?) AS UNSIGNED)) AS last_number
        FROM beneficiaries
        WHERE beneficiary_code LIKE ?
    ");

    $stmt->bind_param('is', $start, $like);
    $stmt->execute();
    $res = $stmt->get_result();

    $next = 1;

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();

        if ($row['last_number'] !== null) {
            $next = intval($row['last_number']) + 1;
        }
    }

    return $prefix . '-' . str_pad($next, 5, '0', STR_PAD_LEFT);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    backHome();
}

$type = strtolower(trim($_POST['queue_type'] ?? ''));
$assistance = strtolower(trim($_POST['assistance_type'] ?? ''));

if ($type === 'priority') {
    $prefix = 'PRIO';
    $queue_type = 'priority';
    $program_type = 'Priority Walk-in Queue';
    $first_name = 'Priority';
    $last_name = 'Walk-in';
    $age = 60;
    $sex = 'Female';
    $sms_opt_in = 0;
    $is_pregnant = 0;
} elseif ($type === 'regular') {
    $queue_type = 'regular';
    $first_name = 'Regular';
    $last_name = 'Walk-in';
    $age = 30;
    $sex = 'Male';
    $sms_opt_in = 0;
    $is_pregnant = 0;

    if ($assistance === 'food') {
        $prefix = 'FDAS';
        $program_type = 'Food Assistance';
    } elseif ($assistance === 'cash_relief') {
        $prefix = 'CRAS';
        $program_type = 'Cash Relief Assistance';
    } else {
        backHome('?error=invalid_type');
    }
} else {
    backHome('?error=invalid_type');
}

$queue_number = nextQueueNumber($conn, $prefix);
$beneficiary_code = nextBeneficiaryCode($conn, $prefix);

$middle_name = '';
$ext_name = '';
$contact_number = '';
$birthday_month = 1;
$birthday_day = 1;
$birthday_year = $type === 'priority' ? 1960 : 2000;
$lgu = 'For Verification';
$national_id = 'Walk-in';
$household_id = '';
$region = 'MIMAROPA Region';
$province = 'For Verification';
$city_municipality = 'For Verification';
$barangay = 'For Verification';

$conn->begin_transaction();

try {
    $insertB = $conn->prepare("
        INSERT INTO beneficiaries (
            beneficiary_code,
            first_name,
            middle_name,
            last_name,
            ext_name,
            contact_number,
            birthday_month,
            birthday_day,
            birthday_year,
            age,
            sex,
            lgu,
            national_id,
            household_id,
            program_type,
            region,
            province,
            city_municipality,
            barangay,
            sms_opt_in,
            is_pregnant
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $insertB->bind_param(
        'ssssssiiiisssssssssii',
        $beneficiary_code,
        $first_name,
        $middle_name,
        $last_name,
        $ext_name,
        $contact_number,
        $birthday_month,
        $birthday_day,
        $birthday_year,
        $age,
        $sex,
        $lgu,
        $national_id,
        $household_id,
        $program_type,
        $region,
        $province,
        $city_municipality,
        $barangay,
        $sms_opt_in,
        $is_pregnant
    );

    if (!$insertB->execute()) {
        throw new Exception('Beneficiary insert failed.');
    }

    $beneficiary_id = $conn->insert_id;

    $insertQ = $conn->prepare("
        INSERT INTO queue_entries (
            queue_number,
            queue_type,
            beneficiary_id,
            transaction_date,
            status,
            workflow_status,
            table_number,
            counter_number,
            called_at,
            assessed_at,
            paid_at
        )
        VALUES (?, ?, ?, CURDATE(), 'waiting', 'WAITING_STEP_2', NULL, NULL, NULL, NULL, NULL)
    ");

    $insertQ->bind_param('ssi', $queue_number, $queue_type, $beneficiary_id);

    if (!$insertQ->execute()) {
        throw new Exception('Queue insert failed.');
    }

    $conn->commit();

    backHome('?queue_generated=1&type=' . urlencode($queue_type) . '&assistance=' . urlencode($assistance) . '&queue=' . urlencode($queue_number));

} catch (Throwable $e) {
    $conn->rollback();
    backHome('?error=queue_failed');
}
?>