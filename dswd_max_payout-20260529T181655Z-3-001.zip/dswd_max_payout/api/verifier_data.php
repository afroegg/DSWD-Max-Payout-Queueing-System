<?php
include('../auth/check.php');
include('../config/db.php');

header('Content-Type: application/json; charset=utf-8');

ini_set('display_errors', 0);
error_reporting(E_ALL);

function hasColumn($conn, $table, $column) {
    $table = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);

    $res = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $res && $res->num_rows > 0;
}

function jsonFail($message) {
    echo json_encode([
        'success' => false,
        'message' => $message,
        'beneficiaries' => []
    ]);
    exit;
}

try {
    $hasPregnant = hasColumn($conn, 'beneficiaries', 'is_pregnant');
    $hasSmsOptIn = hasColumn($conn, 'beneficiaries', 'sms_opt_in');
    $hasProgramType = hasColumn($conn, 'beneficiaries', 'program_type');
    $hasRegion = hasColumn($conn, 'beneficiaries', 'region');
    $hasProvince = hasColumn($conn, 'beneficiaries', 'province');
    $hasCity = hasColumn($conn, 'beneficiaries', 'city_municipality');
    $hasBarangay = hasColumn($conn, 'beneficiaries', 'barangay');
    $hasHousehold = hasColumn($conn, 'beneficiaries', 'household_id');
    $hasNationalId = hasColumn($conn, 'beneficiaries', 'national_id');

    $pregnantSelect = $hasPregnant ? "b.is_pregnant" : "0";
    $pwdSelect = $hasSmsOptIn ? "b.sms_opt_in" : "0";
    $programSelect = $hasProgramType ? "b.program_type" : "''";
    $regionSelect = $hasRegion ? "b.region" : "''";
    $provinceSelect = $hasProvince ? "b.province" : "''";
    $citySelect = $hasCity ? "b.city_municipality" : "''";
    $barangaySelect = $hasBarangay ? "b.barangay" : "''";
    $householdSelect = $hasHousehold ? "b.household_id" : "''";
    $nationalIdSelect = $hasNationalId ? "b.national_id" : "''";

    $sql = "
        SELECT 
            b.id,
            IFNULL(b.beneficiary_code, '') AS beneficiary_code,
            IFNULL(b.last_name, '') AS last_name,
            IFNULL(b.first_name, '') AS first_name,
            IFNULL(b.middle_name, '') AS middle_name,
            IFNULL(b.ext_name, '') AS ext_name,
            IFNULL($regionSelect, '') AS region,
            IFNULL($provinceSelect, '') AS province,
            IFNULL($citySelect, '') AS city_municipality,
            IFNULL($barangaySelect, '') AS barangay,
            IFNULL(b.contact_number, '') AS contact_number,
            IFNULL(b.birthday_month, 0) AS birthday_month,
            IFNULL(b.birthday_day, 0) AS birthday_day,
            IFNULL(b.birthday_year, 0) AS birthday_year,
            IFNULL(b.age, 0) AS age,
            IFNULL(b.sex, '') AS sex,
            IFNULL(b.lgu, '') AS lgu,
            IFNULL($nationalIdSelect, '') AS national_id,
            IFNULL($householdSelect, '') AS household_id,
            IFNULL($programSelect, '') AS program_type,
            IFNULL($pwdSelect, 0) AS sms_opt_in,
            IFNULL($pregnantSelect, 0) AS is_pregnant,
            IFNULL(q.queue_number, '') AS queue_number,
            IFNULL(q.queue_type, '') AS queue_type,
            IFNULL(q.workflow_status, '') AS workflow_status
        FROM beneficiaries b
        LEFT JOIN (
            SELECT q1.*
            FROM queue_entries q1
            INNER JOIN (
                SELECT beneficiary_id, MAX(id) AS latest_id
                FROM queue_entries
                WHERE DATE(transaction_date) = CURDATE()
                AND (
                    workflow_status IS NULL 
                    OR workflow_status != 'CANCELLED'
                )
                GROUP BY beneficiary_id
            ) latest ON latest.latest_id = q1.id
        ) q ON q.beneficiary_id = b.id
        ORDER BY 
            CASE 
                WHEN q.queue_type = 'priority' THEN 0
                WHEN q.queue_type = 'regular' THEN 1
                ELSE 2
            END ASC,
            CASE 
                WHEN q.id IS NULL THEN 1 
                ELSE 0 
            END ASC,
            q.id ASC,
            b.last_name ASC,
            b.first_name ASC,
            b.id ASC
    ";

    $result = $conn->query($sql);

    if (!$result) {
        jsonFail('SQL Error: ' . $conn->error);
    }

    $beneficiaries = [];

    while ($row = $result->fetch_assoc()) {
        $isPwd = intval($row['sms_opt_in'] ?? 0);
        $isPregnant = intval($row['is_pregnant'] ?? 0);
        $age = intval($row['age'] ?? 0);

        if ($isPwd === 1) {
            $category = 'PWD';
        } elseif ($isPregnant === 1) {
            $category = 'Pregnant';
        } elseif ($age >= 60) {
            $category = 'Senior';
        } else {
            $category = 'Regular';
        }

        $beneficiaries[] = [
            'id' => intval($row['id']),
            'beneficiary_code' => $row['beneficiary_code'],
            'last_name' => $row['last_name'],
            'first_name' => $row['first_name'],
            'middle_name' => $row['middle_name'],
            'ext_name' => $row['ext_name'],
            'region' => $row['region'],
            'province' => $row['province'],
            'city_municipality' => $row['city_municipality'],
            'barangay' => $row['barangay'],
            'contact_number' => $row['contact_number'],
            'birthday_month' => intval($row['birthday_month']),
            'birthday_day' => intval($row['birthday_day']),
            'birthday_year' => intval($row['birthday_year']),
            'age' => intval($row['age']),
            'sex' => $row['sex'],
            'lgu' => $row['lgu'],
            'national_id' => $row['national_id'],
            'household_id' => $row['household_id'],
            'program_type' => $row['program_type'],
            'sms_opt_in' => $isPwd,
            'is_pwd' => $isPwd,
            'is_pregnant' => $isPregnant,
            'category' => $category,
            'queue_number' => $row['queue_number'],
            'queue_type' => $row['queue_type'],
            'workflow_status' => $row['workflow_status']
        ];
    }

    echo json_encode([
        'success' => true,
        'count' => count($beneficiaries),
        'beneficiaries' => $beneficiaries
    ]);
    exit;

} catch (Throwable $e) {
    jsonFail('Server error: ' . $e->getMessage());
}
?>