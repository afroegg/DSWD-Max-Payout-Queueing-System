<?php
include('../auth/check.php');
include('../config/db.php');

function redirectWithToast($redirect, $type, $message) {
    $allowedRedirects = [
        '../staff/assessment_screen.php',
        '../staff/confirmation_screen.php'
    ];

    if (!in_array($redirect, $allowedRedirects, true)) {
        $redirect = '../staff/assessment_screen.php';
    }

    $separator = strpos($redirect, '?') === false ? '?' : '&';

    header(
        'Location: ' . $redirect .
        $separator .
        'toast_type=' . urlencode($type) .
        '&toast_msg=' . urlencode($message)
    );
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../staff/assessment_screen.php');
    exit;
}

$queue_id = intval($_POST['queue_id'] ?? 0);
$redirect = trim($_POST['redirect'] ?? '../staff/assessment_screen.php');

if ($queue_id <= 0) {
    redirectWithToast($redirect, 'error', 'Invalid queue selected.');
}

try {
    $check = $conn->prepare("SELECT id, workflow_status FROM queue_entries WHERE id = ?");
    $check->bind_param('i', $queue_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows === 0) {
        redirectWithToast($redirect, 'error', 'Queue not found.');
    }

    $queue = $result->fetch_assoc();

    if ($queue['workflow_status'] === 'PAID') {
        redirectWithToast($redirect, 'error', 'Paid queues cannot be cancelled.');
    }

    if ($queue['workflow_status'] === 'CANCELLED') {
        redirectWithToast($redirect, 'error', 'Queue is already cancelled.');
    }

    $stmt = $conn->prepare("
        UPDATE queue_entries 
        SET workflow_status = 'CANCELLED',
            counter_number = NULL,
            table_number = NULL
        WHERE id = ?
    ");

    $stmt->bind_param('i', $queue_id);
    $stmt->execute();

    redirectWithToast($redirect, 'success', 'Queue cancelled successfully.');

} catch (Exception $e) {
    redirectWithToast($redirect, 'error', 'Failed to cancel queue.');
}
?>