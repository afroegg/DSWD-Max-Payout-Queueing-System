<?php
include('../auth/check.php');
include('../config/db.php');

date_default_timezone_set('Asia/Manila');

function goBack() {
    header('Location: ../staff/verifier.php');
    exit;
}

function nextQueueNumber($conn, $prefix) {
    $like = $prefix . '-%';
    $start = strlen($prefix) + 2;

    $stmt = $conn->prepare("
        SELECT MAX(CAST(SUBSTRING(queue_number, ?) AS UNSIGNED)) AS last_number
        FROM queue_entries
        WHERE DATE(transaction_date)=CURDATE()
        AND queue_number LIKE ?
    ");

    $stmt->bind_param('is', $start, $like);
    $stmt->execute();
    $res = $stmt->get_result();

    $next = 1;

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();

        if ($row['last_number'] !== null) {
            $next = intval($row['last_number']) + 1;
        }
    }

    return $prefix . '-' . str_pad($next, 5, '0', STR_PAD_LEFT);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    goBack();
}

$beneficiary_id = intval($_POST['beneficiary_id'] ?? 0);
$new_type = strtolower(trim($_POST['new_queue_type'] ?? ''));

if ($beneficiary_id <= 0 || !in_array($new_type, ['regular', 'priority'])) {
    goBack();
}

if ($new_type === 'priority') {
    $prefix = 'PRIO';
    $queue_type = 'priority';
    $program_type = 'Priority Walk-in Queue';
} else {
    $prefix = 'PAL';
    $queue_type = 'regular';
    $program_type = 'Regular Walk-in Queue';
}

$new_queue_number = nextQueueNumber($conn, $prefix);

$conn->begin_transaction();

try {
    $checkB = $conn->prepare("SELECT id FROM beneficiaries WHERE id=? LIMIT 1");
    $checkB->bind_param('i', $beneficiary_id);
    $checkB->execute();
    $bRes = $checkB->get_result();

    if (!$bRes || $bRes->num_rows === 0) {
        throw new Exception('Beneficiary not found.');
    }

    $updateB = $conn->prepare("
        UPDATE beneficiaries
        SET program_type=?
        WHERE id=?
    ");

    $updateB->bind_param('si', $program_type, $beneficiary_id);
    $updateB->execute();

    $findQ = $conn->prepare("
        SELECT id, workflow_status
        FROM queue_entries
        WHERE beneficiary_id=?
        AND DATE(transaction_date)=CURDATE()
        AND (workflow_status IS NULL OR workflow_status!='CANCELLED')
        ORDER BY id DESC
        LIMIT 1
    ");

    $findQ->bind_param('i', $beneficiary_id);
    $findQ->execute();
    $qRes = $findQ->get_result();

    if ($qRes && $qRes->num_rows > 0) {
        $q = $qRes->fetch_assoc();
        $queue_id = intval($q['id']);
        $status = $q['workflow_status'];

        if (in_array($status, ['CALLED_STEP_2', 'WAITING_STEP_3', 'CALLED_STEP_3', 'PAID'])) {
            throw new Exception('Queue already moved forward and cannot be regenerated.');
        }

        $updateQ = $conn->prepare("
            UPDATE queue_entries
            SET queue_number=?,
                queue_type=?,
                status='waiting',
                workflow_status='WAITING_STEP_2',
                counter_number=NULL,
                table_number=NULL,
                called_at=NULL,
                assessed_at=NULL,
                paid_at=NULL
            WHERE id=?
        ");

        $updateQ->bind_param('ssi', $new_queue_number, $queue_type, $queue_id);
        $updateQ->execute();

    } else {
        $insertQ = $conn->prepare("
            INSERT INTO queue_entries (
                queue_number,
                queue_type,
                beneficiary_id,
                transaction_date,
                status,
                workflow_status,
                table_number,
                counter_number,
                called_at,
                assessed_at,
                paid_at
            )
            VALUES (?, ?, ?, CURDATE(), 'waiting', 'WAITING_STEP_2', NULL, NULL, NULL, NULL, NULL)
        ");

        $insertQ->bind_param('ssi', $new_queue_number, $queue_type, $beneficiary_id);
        $insertQ->execute();
    }

    $conn->commit();
    goBack();

} catch (Throwable $e) {
    $conn->rollback();
    goBack();
}
?>