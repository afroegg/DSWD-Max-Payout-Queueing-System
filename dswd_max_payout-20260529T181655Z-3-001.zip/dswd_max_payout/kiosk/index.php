<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>DSWD MIMAROPA Queue Kiosk</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #e8edf4;
    color: #111827;
    min-height: 100vh;
}

.screen {
    min-height: 100vh;
    display: none;
}

.screen.active {
    display: flex;
}

.start-screen {
    align-items: center;
    justify-content: center;
    padding: 28px;
}

.kiosk-home-card {
    width: 96%;
    max-width: 1480px;
    background: white;
    border-radius: 24px;
    padding: 34px 30px 30px;
    box-shadow: 0 18px 45px rgba(15, 23, 42, .12);
}

.kiosk-title {
    text-align: center;
    margin-bottom: 34px;
}

.kiosk-title h1 {
    margin: 0;
    color: #0b2e83;
    font-size: 38px;
    letter-spacing: 8px;
    font-weight: 1000;
}

.kiosk-title p {
    margin: 18px 0 0;
    color: #4b5563;
    font-size: 18px;
    font-weight: 800;
    letter-spacing: .8px;
}

.kiosk-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 28px;
}

.queue-form {
    margin: 0;
    display: flex;
}

.queue-form .kiosk-card {
    width: 100%;
}

.kiosk-card {
    min-height: 260px;
    border: none;
    border-radius: 22px;
    cursor: pointer;
    color: white;
    box-shadow: 0 8px 0 rgba(3, 27, 78, .75), 0 16px 28px rgba(15, 23, 42, .18);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    text-align: center;
    transition: .12s ease;
}

.kiosk-card:hover {
    transform: translateY(-2px);
}

.kiosk-card:active {
    transform: translateY(4px);
    box-shadow: 0 4px 0 rgba(3, 27, 78, .75), 0 10px 20px rgba(15, 23, 42, .18);
}

.regular-card {
    background: linear-gradient(180deg, #125ed8, #06439f);
}

.priority-card {
    background: linear-gradient(180deg, #ff9b38, #f97316);
    box-shadow: 0 8px 0 rgba(145, 64, 14, .9), 0 16px 28px rgba(15, 23, 42, .18);
}

.icon-box {
    width: 88px;
    height: 88px;
    border-radius: 22px;
    border: 2px solid rgba(255,255,255,.25);
    background: rgba(255,255,255,.12);
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 22px;
}

.icon-box .material-icons {
    font-size: 50px;
}

.kiosk-card h2 {
    margin: 0;
    font-size: 38px;
    font-weight: 1000;
    letter-spacing: 5px;
    line-height: 1.15;
}

.success-screen {
    align-items: center;
    justify-content: center;
    padding: 30px;
    background: #f3f6fb;
}

.success-card {
    width: 760px;
    max-width: 96%;
    background: white;
    border-radius: 24px;
    padding: 38px 32px;
    text-align: center;
    border: 1px solid #d6dce8;
    box-shadow: 0 14px 35px rgba(15,23,42,.14);
}

.success-icon,
.error-icon {
    width: 90px;
    height: 90px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 18px;
}

.success-icon {
    background: #dcfce7;
    color: #166534;
}

.error-icon {
    background: #fee2e2;
    color: #991b1b;
}

.success-icon .material-icons,
.error-icon .material-icons {
    font-size: 54px;
}

.success-card h1 {
    margin: 0;
    color: #166534;
    font-size: 32px;
}

.success-card.error h1 {
    color: #991b1b;
}

.success-card p {
    color: #374151;
    font-size: 16px;
    line-height: 1.5;
}

.code-label {
    color: #64748b;
    font-size: 14px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: .7px;
    margin-top: 18px;
}

.code-box {
    background: #eff6ff;
    color: #00008b;
    border: 1px solid #bfdbfe;
    padding: 18px 24px;
    border-radius: 14px;
    font-size: 42px;
    font-weight: 1000;
    margin: 12px auto 20px;
    display: inline-block;
    letter-spacing: 2px;
}

.done-btn {
    min-height: 54px;
    border: none;
    border-radius: 999px;
    padding: 0 34px;
    font-size: 16px;
    font-weight: 900;
    cursor: pointer;
    background: #0b2e83;
    color: white;
}

.print-btn {
    min-height: 54px;
    border: none;
    border-radius: 999px;
    padding: 0 34px;
    font-size: 16px;
    font-weight: 900;
    cursor: pointer;
    background: #16a34a;
    color: white;
    margin-right: 8px;
}

.actions {
    display: flex;
    justify-content: center;
    gap: 10px;
    flex-wrap: wrap;
}

.stub {
    display: none;
}

.regular-modal {
    position: fixed;
    inset: 0;
    background: rgba(15,23,42,.62);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 99999;
    padding: 24px;
}

.regular-modal-box {
    width: 620px;
    max-width: 96%;
    background: white;
    border-radius: 24px;
    padding: 30px;
    text-align: center;
    box-shadow: 0 20px 55px rgba(15,23,42,.35);
}

.regular-modal-box h2 {
    margin: 0;
    color: #0b2e83;
    font-size: 30px;
    font-weight: 1000;
    letter-spacing: 1px;
}

.regular-modal-box p {
    margin: 10px 0 24px;
    color: #64748b;
    font-size: 16px;
    font-weight: 800;
}

.regular-choice-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
}

.regular-choice-grid form {
    margin: 0;
}

.regular-choice-btn {
    width: 100%;
    min-height: 145px;
    border: 0;
    border-radius: 18px;
    color: white;
    font-size: 22px;
    font-weight: 1000;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    box-shadow: 0 8px 0 rgba(15,23,42,.25);
}

.regular-choice-btn:active {
    transform: translateY(4px);
    box-shadow: 0 4px 0 rgba(15,23,42,.25);
}

.regular-choice-btn .material-icons {
    font-size: 44px;
    margin-bottom: 10px;
}

.cash-btn {
    background: linear-gradient(180deg, #15803d, #16a34a);
}

.food-btn {
    background: linear-gradient(180deg, #ca8a04, #f59e0b);
}

.regular-modal-cancel {
    width: 100%;
    height: 48px;
    border: 0;
    border-radius: 12px;
    background: #e5e7eb;
    color: #111827;
    font-weight: 1000;
    cursor: pointer;
    margin-top: 16px;
}

@media(max-width:650px) {
    .regular-choice-grid {
        grid-template-columns: 1fr;
    }
}

@media print {
    body * {
        visibility: hidden;
    }

    .stub,
    .stub * {
        visibility: visible;
    }

    .stub {
        display: block;
        position: absolute;
        inset: 0;
        padding: 20px;
        font-family: Arial, sans-serif;
        text-align: center;
    }

    .stub-box {
        border: 2px dashed #111827;
        padding: 18px;
        width: 320px;
        margin: 0 auto;
    }

    .stub-title {
        font-size: 16px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .stub-queue {
        font-size: 38px;
        font-weight: 1000;
        margin: 12px 0;
    }

    .stub-note {
        font-size: 12px;
        margin-top: 10px;
    }
}

@media(max-width: 900px) {
    .kiosk-grid {
        grid-template-columns: 1fr;
    }

    .kiosk-card {
        min-height: 220px;
    }
}

@media(max-width: 650px) {
    .kiosk-title h1 {
        font-size: 28px;
        letter-spacing: 3px;
    }

    .kiosk-title p {
        font-size: 15px;
    }

    .kiosk-card h2 {
        font-size: 28px;
        letter-spacing: 3px;
    }

    .code-box {
        font-size: 32px;
    }
}
</style>
</head>

<body>

<section id="startScreen" class="screen start-screen active">
    <div class="kiosk-home-card">
        <div class="kiosk-title">
            <h1>DSWD MIMAROPA QUEUE KIOSK</h1>
            <p>Tap your queue type to instantly receive a queue number.</p>
        </div>

        <div class="kiosk-grid">
            <div class="queue-form">
    <button type="button" class="kiosk-card regular-card" onclick="openRegularModal()">
        <div class="icon-box">
            <span class="material-icons">groups</span>
        </div>
        <h2>REGULAR<br>QUEUE</h2>
    </button>
</div>

            <form method="POST" action="../api/kiosk_generate_queue.php" class="queue-form">
                <input type="hidden" name="queue_type" value="priority">

                <button type="submit" class="kiosk-card priority-card">
                    <div class="icon-box">
                        <span class="material-icons">priority_high</span>
                    </div>
                    <h2>PRIORITY<br>QUEUE</h2>
                </button>
            </form>
        </div>
    </div>
</section>

<section id="successScreen" class="screen success-screen">
    <div class="success-card" id="successCard">
        <div id="successIcon" class="success-icon">
            <span class="material-icons" id="successIconText">check_circle</span>
        </div>

        <h1 id="successTitle">Queue Generated</h1>

        <p id="successMessage">
            Please keep your queue number and wait for it to be called.
        </p>

        <div class="code-label" id="successLabel">Queue Number</div>
        <div class="code-box" id="codeBox">---</div>

        <div class="actions">
            <button class="print-btn" onclick="window.print()">
                Print Stub
            </button>

            <button class="done-btn" onclick="goHome()">
                Done
            </button>
        </div>
    </div>
</section>

<div id="regularModal" class="regular-modal">
    <div class="regular-modal-box">
        <h2>Select Regular Assistance</h2>
        <p>Please choose the assistance type for your regular queue.</p>

        <div class="regular-choice-grid">
            <form method="POST" action="../api/kiosk_generate_queue.php">
                <input type="hidden" name="queue_type" value="regular">
                <input type="hidden" name="assistance_type" value="cash_relief">

                <button type="submit" class="regular-choice-btn cash-btn">
                    <span class="material-icons">payments</span>
                    Cash Relief
                </button>
            </form>

            <form method="POST" action="../api/kiosk_generate_queue.php">
                <input type="hidden" name="queue_type" value="regular">
                <input type="hidden" name="assistance_type" value="food">

                <button type="submit" class="regular-choice-btn food-btn">
                    <span class="material-icons">restaurant</span>
                    Food
                </button>
            </form>
        </div>

        <button type="button" class="regular-modal-cancel" onclick="closeRegularModal()">
            Cancel
        </button>
    </div>
</div>

<div class="stub">
    <div class="stub-box">
        <div class="stub-title">DSWD MIMAROPA QUEUE STUB</div>
        <div id="stubType">QUEUE NUMBER</div>
        <div class="stub-queue" id="stubQueue">---</div>
        <div id="stubDate"></div>
        <div class="stub-note">Please wait for your number to be called.</div>
    </div>
</div>

<script>
function showOnly(id) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });

    document.getElementById(id).classList.add('active');
}

function goHome() {
    window.history.replaceState({}, document.title, 'index.php');
    showOnly('startScreen');
}

function showSuccess(queue, type) {
    const isPriority = type === 'priority';

    document.getElementById('successCard').classList.remove('error');
    document.getElementById('successIcon').className = 'success-icon';
    document.getElementById('successIconText').innerText = 'check_circle';

   const assistance = new URLSearchParams(window.location.search).get('assistance') || '';

let titleText = 'Regular Queue Generated';

if (isPriority) {
    titleText = 'Priority Queue Generated';
} else if (assistance === 'food') {
    titleText = 'Food Assistance Queue Generated';
} else if (assistance === 'cash_relief') {
    titleText = 'Cash Relief Queue Generated';
}

document.getElementById('successTitle').innerText = titleText;
    document.getElementById('successMessage').innerText = 'Please keep your queue number and wait for it to be called for assessment.';
    document.getElementById('successLabel').innerText = 'Queue Number';
    document.getElementById('codeBox').innerText = queue || '---';

    document.getElementById('stubType').innerText = isPriority ? 'PRIORITY QUEUE' : 'REGULAR QUEUE';
    document.getElementById('stubQueue').innerText = queue || '---';
    document.getElementById('stubDate').innerText = new Date().toLocaleString();

    showOnly('successScreen');
}

function showError() {
    document.getElementById('successCard').classList.add('error');
    document.getElementById('successIcon').className = 'error-icon';
    document.getElementById('successIconText').innerText = 'error';

    document.getElementById('successTitle').innerText = 'Queue Failed';
    document.getElementById('successMessage').innerText = 'Unable to generate queue number. Please ask staff for assistance.';
    document.getElementById('successLabel').innerText = 'Status';
    document.getElementById('codeBox').innerText = 'FAILED';

    document.getElementById('stubType').innerText = 'QUEUE FAILED';
    document.getElementById('stubQueue').innerText = 'FAILED';
    document.getElementById('stubDate').innerText = new Date().toLocaleString();

    showOnly('successScreen');
}

function openRegularModal() {
    document.getElementById('regularModal').style.display = 'flex';
}

function closeRegularModal() {
    document.getElementById('regularModal').style.display = 'none';
}

document.getElementById('regularModal').addEventListener('click', function(event) {
    if (event.target === this) {
        closeRegularModal();
    }
});

try {
    const params = new URLSearchParams(window.location.search);

    if (params.get('queue_generated') === '1') {
        showSuccess(params.get('queue') || '---', params.get('type') || 'regular');
        window.history.replaceState({}, document.title, 'index.php');
    }

    if (params.get('error') === 'queue_failed' || params.get('error') === 'invalid_type') {
        showError();
        window.history.replaceState({}, document.title, 'index.php');
    }
} catch (e) {
    console.error(e);
}
</script>

</body>
</html>