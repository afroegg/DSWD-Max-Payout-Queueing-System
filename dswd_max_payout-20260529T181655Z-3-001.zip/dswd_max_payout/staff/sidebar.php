<?php
$current = basename($_SERVER['PHP_SELF']);
?>

<aside class="sidebar">
    <div class="logo">ADMIN</div>

    <nav>
        <a href="verifier.php" class="<?php echo $current === 'verifier.php' ? 'active' : ''; ?>">
            <span class="material-icons">fact_check</span>Verify
        </a>

        <a href="assessment_screen.php" class="<?php echo ($current === 'assessment_screen.php' || $current === 'eligibility_form.php') ? 'active' : ''; ?>">
            <span class="material-icons">assignment</span>Assessment
        </a>

        <a href="confirmation_screen.php" class="<?php echo $current === 'confirmation_screen.php' ? 'active' : ''; ?>">
            <span class="material-icons">payments</span>Confirmation
        </a>

        <a href="analytics.php" class="<?php echo $current === 'analytics.php' ? 'active' : ''; ?>">
            <span class="material-icons">analytics</span>Analytics
        </a>

        <a href="settings.php" class="<?php echo $current === 'settings.php' ? 'active' : ''; ?>">
            <span class="material-icons">settings</span>Settings
        </a>
    </nav>

    <div class="sidebar-footer">
        <a href="../kiosk/index.php" target="_blank">
            <span class="material-icons">touch_app</span>Kiosk
        </a>

        <a href="counter_display.php" target="_blank">
            <span class="material-icons">desktop_windows</span>Counter Display
        </a>

        <a href="../auth/logout.php">
            <span class="material-icons">logout</span>Logout
        </a>
    </div>
</aside>

<style>
.ui-confirm-overlay {
    position: fixed;
    inset: 0;
    background: rgba(15,23,42,.55);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 999999;
    padding: 20px;
}

.ui-confirm-box {
    width: 420px;
    max-width: 95%;
    background: #fff;
    border-radius: 18px;
    padding: 24px;
    box-shadow: 0 18px 50px rgba(15,23,42,.32);
    border: 1px solid #e5e7eb;
    text-align: center;
}

.ui-confirm-icon {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    background: #fee2e2;
    color: #dc2626;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 14px;
}

.ui-confirm-icon .material-icons {
    font-size: 42px;
}

.ui-confirm-box h2 {
    margin: 0;
    color: #111827;
    font-size: 22px;
}

.ui-confirm-box p {
    margin: 10px 0 20px;
    color: #64748b;
    font-size: 14px;
    line-height: 1.5;
}

.ui-confirm-actions {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
}

.ui-confirm-btn {
    height: 44px;
    border: none;
    border-radius: 10px;
    font-weight: 900;
    cursor: pointer;
}

.ui-confirm-cancel {
    background: #e5e7eb;
    color: #111827;
}

.ui-confirm-proceed {
    background: #dc2626;
    color: #fff;
}
</style>

<div id="uiConfirmOverlay" class="ui-confirm-overlay">
    <div class="ui-confirm-box">
        <div class="ui-confirm-icon">
            <span class="material-icons">warning</span>
        </div>

        <h2 id="uiConfirmTitle">Confirm Action</h2>
        <p id="uiConfirmMessage">Are you sure you want to continue?</p>

        <div class="ui-confirm-actions">
            <button type="button" class="ui-confirm-btn ui-confirm-cancel" onclick="closeUiConfirm()">Cancel</button>
            <button type="button" class="ui-confirm-btn ui-confirm-proceed" onclick="proceedUiConfirm()">Continue</button>
        </div>
    </div>
</div>

<script>
let pendingConfirmForm = null;

function openUiConfirm(form, title, message) {
    pendingConfirmForm = form;

    document.getElementById('uiConfirmTitle').textContent = title || 'Confirm Action';
    document.getElementById('uiConfirmMessage').textContent = message || 'Are you sure you want to continue?';
    document.getElementById('uiConfirmOverlay').style.display = 'flex';
}

function closeUiConfirm() {
    pendingConfirmForm = null;
    document.getElementById('uiConfirmOverlay').style.display = 'none';
}

function proceedUiConfirm() {
    if (pendingConfirmForm) {
        const form = pendingConfirmForm;
        pendingConfirmForm = null;
        form.dataset.confirmed = '1';
        form.submit();
    }

    closeUiConfirm();
}

document.addEventListener('submit', function(e) {
    const form = e.target;

    if (!form || form.dataset.confirmed === '1') return;

    const action = (form.getAttribute('action') || '').toLowerCase();

    if (action.includes('remove_beneficiary.php')) {
        e.preventDefault();
        openUiConfirm(
            form,
            'Delete Beneficiary?',
            'This will remove the beneficiary record from the system. Continue only if you are sure.'
        );
    }

    if (action.includes('cancel_queue.php')) {
        e.preventDefault();
        openUiConfirm(
            form,
            'Cancel Queue?',
            'This will cancel the current queue record. The beneficiary will no longer appear in the active queue.'
        );
    }
});
</script>