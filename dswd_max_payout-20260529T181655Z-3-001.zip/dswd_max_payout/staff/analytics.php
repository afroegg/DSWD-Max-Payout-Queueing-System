<?php
include('../auth/check.php');
include('../config/db.php');

date_default_timezone_set('Asia/Manila');

function one($conn, $sql) {
    $res = $conn->query($sql);
    if (!$res) return 0;
    $row = $res->fetch_assoc();
    return intval($row['total'] ?? 0);
}

function amountOne($conn, $sql) {
    $res = $conn->query($sql);
    if (!$res) return 0;
    $row = $res->fetch_assoc();
    return floatval($row['total'] ?? 0);
}

function rows($conn, $sql) {
    $out = [];
    $res = $conn->query($sql);
    if ($res) {
        while ($r = $res->fetch_assoc()) {
            $out[] = $r;
        }
    }
    return $out;
}

function pct($part, $total) {
    return $total > 0 ? round((floatval($part) / floatval($total)) * 100, 1) : 0;
}

function money($value) {
    return '₱' . number_format(floatval($value), 2);
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function color($index) {
    $colors = [
        '#2563eb',
        '#f97316',
        '#16a34a',
        '#7c3aed',
        '#db2777',
        '#0ea5e9',
        '#475569',
        '#dc2626'
    ];

    return $colors[$index % count($colors)];
}

function totalValue($items, $field = 'value') {
    $total = 0;
    foreach ($items as $item) {
        $total += intval($item[$field] ?? 0);
    }
    return $total;
}

function pieStyle($items, $field = 'value') {
    $total = totalValue($items, $field);

    if ($total <= 0) {
        return 'background:#e5e7eb;';
    }

    $start = 0;
    $parts = [];

    foreach ($items as $i => $item) {
        $value = intval($item[$field] ?? 0);
        if ($value <= 0) continue;

        $deg = ($value / $total) * 360;
        $end = $start + $deg;

        $parts[] = color($i) . ' ' . $start . 'deg ' . $end . 'deg';
        $start = $end;
    }

    return 'background:conic-gradient(' . implode(',', $parts) . ');';
}

$today = date('M d, Y');
$loadedAt = date('h:i:s A');

/* ================= QUEUE WORKFLOW ================= */

$totalQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE()
");

$waitingAssessment = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE() 
    AND workflow_status='WAITING_STEP_2'
");

$calledAssessment = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE() 
    AND workflow_status='CALLED_STEP_2'
");

$waitingPayout = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE() 
    AND workflow_status='WAITING_STEP_3'
");

$calledPayout = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE() 
    AND workflow_status='CALLED_STEP_3'
");

$heldQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE() 
    AND workflow_status='HELD'
");

$paidQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE() 
    AND workflow_status='PAID'
");

$cancelledQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE() 
    AND workflow_status='CANCELLED'
");

$activeQueues = $waitingAssessment + $calledAssessment + $waitingPayout + $calledPayout + $heldQueues;

/* ================= ALLOWED ASSISTANCE TYPES ONLY ================= */

$foodQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries
    WHERE DATE(transaction_date)=CURDATE()
    AND queue_number LIKE 'FDAS-%'
");

$cashReliefQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries
    WHERE DATE(transaction_date)=CURDATE()
    AND queue_number LIKE 'CRAS-%'
");

$priorityQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries
    WHERE DATE(transaction_date)=CURDATE()
    AND (
        queue_number LIKE 'PRIO-%'
        OR queue_type='priority'
    )
");

$regularQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE() 
    AND queue_type='regular'
    AND (
        queue_number LIKE 'FDAS-%'
        OR queue_number LIKE 'CRAS-%'
    )
");

/* ================= BENEFICIARIES ================= */

$totalBeneficiaries = one($conn, "
    SELECT COUNT(*) AS total 
    FROM beneficiaries
");

$todayClients = one($conn, "
    SELECT COUNT(DISTINCT beneficiary_id) AS total 
    FROM queue_entries 
    WHERE DATE(transaction_date)=CURDATE()
");

$pwdTotal = one($conn, "
    SELECT COUNT(*) AS total 
    FROM beneficiaries 
    WHERE sms_opt_in=1
");

$pregnantTotal = one($conn, "
    SELECT COUNT(*) AS total 
    FROM beneficiaries 
    WHERE is_pregnant=1
");

$seniorTotal = one($conn, "
    SELECT COUNT(*) AS total 
    FROM beneficiaries 
    WHERE age>=60
");

$regularCategoryTotal = one($conn, "
    SELECT COUNT(*) AS total 
    FROM beneficiaries 
    WHERE age<60 
    AND sms_opt_in=0 
    AND is_pregnant=0
");

$pwdQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries q 
    JOIN beneficiaries b ON b.id=q.beneficiary_id 
    WHERE DATE(q.transaction_date)=CURDATE() 
    AND b.sms_opt_in=1
");

$pregnantQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries q 
    JOIN beneficiaries b ON b.id=q.beneficiary_id 
    WHERE DATE(q.transaction_date)=CURDATE() 
    AND b.is_pregnant=1
");

$seniorQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries q 
    JOIN beneficiaries b ON b.id=q.beneficiary_id 
    WHERE DATE(q.transaction_date)=CURDATE() 
    AND b.age>=60
");

$regularOnlyQueues = one($conn, "
    SELECT COUNT(*) AS total 
    FROM queue_entries q 
    JOIN beneficiaries b ON b.id=q.beneficiary_id 
    WHERE DATE(q.transaction_date)=CURDATE() 
    AND b.age<60 
    AND b.sms_opt_in=0 
    AND b.is_pregnant=0
");

/* ================= GIS / ELIGIBILITY ================= */

$gisDrafts = one($conn, "
    SELECT COUNT(*) AS total 
    FROM eligibility_forms e 
    JOIN queue_entries q ON q.id=e.queue_entry_id 
    WHERE DATE(q.transaction_date)=CURDATE() 
    AND e.form_locked=0
");

$gisLocked = one($conn, "
    SELECT COUNT(*) AS total 
    FROM eligibility_forms e 
    JOIN queue_entries q ON q.id=e.queue_entry_id 
    WHERE DATE(q.transaction_date)=CURDATE() 
    AND e.form_locked=1
");

$gisEligible = one($conn, "
    SELECT COUNT(*) AS total 
    FROM eligibility_forms e 
    JOIN queue_entries q ON q.id=e.queue_entry_id 
    WHERE DATE(q.transaction_date)=CURDATE() 
    AND e.form_locked=1 
    AND e.eligibility_status='Eligible'
");

$gisNotEligible = one($conn, "
    SELECT COUNT(*) AS total 
    FROM eligibility_forms e 
    JOIN queue_entries q ON q.id=e.queue_entry_id 
    WHERE DATE(q.transaction_date)=CURDATE() 
    AND e.form_locked=1 
    AND e.eligibility_status='Not Eligible'
");

$approvedAmount = amountOne($conn, "
    SELECT IFNULL(SUM(e.approved_cash_amount),0) AS total 
    FROM eligibility_forms e 
    JOIN queue_entries q ON q.id=e.queue_entry_id 
    WHERE DATE(q.transaction_date)=CURDATE() 
    AND e.form_locked=1 
    AND e.eligibility_status='Eligible'
");

/* ================= ROW DATA ================= */

$workflowRows = [
    ['label' => 'Waiting Assessment', 'value' => $waitingAssessment],
    ['label' => 'Called Assessment', 'value' => $calledAssessment],
    ['label' => 'Waiting Payout / Release', 'value' => $waitingPayout],
    ['label' => 'Called Payout / Release', 'value' => $calledPayout],
    ['label' => 'Held', 'value' => $heldQueues],
    ['label' => 'Paid', 'value' => $paidQueues],
    ['label' => 'Cancelled', 'value' => $cancelledQueues]
];

$queueTypeRows = [
    ['label' => 'FDAS - Food Assistance', 'value' => $foodQueues],
    ['label' => 'CRAS - Cash Relief Assistance', 'value' => $cashReliefQueues],
    ['label' => 'PRIO - Priority', 'value' => $priorityQueues]
];

$categoryRows = [
    ['label' => 'PWD', 'value' => $pwdTotal, 'queues' => $pwdQueues],
    ['label' => 'Pregnant', 'value' => $pregnantTotal, 'queues' => $pregnantQueues],
    ['label' => 'Senior', 'value' => $seniorTotal, 'queues' => $seniorQueues],
    ['label' => 'Regular', 'value' => $regularCategoryTotal, 'queues' => $regularOnlyQueues]
];

$gisRows = [
    ['label' => 'Draft', 'value' => $gisDrafts],
    ['label' => 'Locked Eligible', 'value' => $gisEligible],
    ['label' => 'Locked Not Eligible', 'value' => $gisNotEligible]
];

$sexRows = rows($conn, "
    SELECT 
        IFNULL(NULLIF(sex,''),'Not encoded') AS label,
        COUNT(*) AS value
    FROM beneficiaries
    GROUP BY label
    ORDER BY value DESC
");

$mimaropaLocationRows = rows($conn, "
    SELECT 
        IFNULL(NULLIF(lgu,''),'Unknown') AS label,
        COUNT(*) AS value
    FROM beneficiaries
    WHERE region LIKE '%MIMAROPA%'
       OR region LIKE '%IV-B%'
       OR region LIKE '%Region IV-B%'
    GROUP BY label
    ORDER BY value DESC
    LIMIT 6
");

$incomeRows = rows($conn, "
    SELECT 
        IFNULL(NULLIF(e.income_source,''),'Not encoded') AS label,
        COUNT(*) AS value
    FROM eligibility_forms e
    JOIN queue_entries q ON q.id=e.queue_entry_id
    WHERE DATE(q.transaction_date)=CURDATE()
    GROUP BY label
    ORDER BY value DESC
");

$programRows = rows($conn, "
    SELECT 
        CASE
            WHEN program_type='Food Assistance' OR beneficiary_code LIKE 'FDAS-%' THEN 'Food Assistance'
            WHEN program_type='Cash Relief Assistance' OR beneficiary_code LIKE 'CRAS-%' THEN 'Cash Relief Assistance'
            WHEN program_type IN ('Priority Assistance','Priority') OR beneficiary_code LIKE 'PRIO-%' THEN 'Priority'
            ELSE 'Other'
        END AS label,
        COUNT(*) AS value
    FROM beneficiaries
    WHERE program_type IN ('Food Assistance', 'Cash Relief Assistance', 'Priority Assistance', 'Priority')
       OR beneficiary_code LIKE 'FDAS-%'
       OR beneficiary_code LIKE 'CRAS-%'
       OR beneficiary_code LIKE 'PRIO-%'
    GROUP BY label
    ORDER BY value DESC
");

$paidPercent = pct($paidQueues, $totalQueues);
$activePercent = pct($activeQueues, $totalQueues);
$priorityPercent = pct($priorityQueues, $totalQueues);
$regularPercent = pct($regularQueues, $totalQueues);
$gisLockedPercent = pct($gisLocked, $totalQueues);

$queueTypeTotal = totalValue($queueTypeRows);
$categoryTotal = totalValue($categoryRows);
$workflowTotal = totalValue($workflowRows);
$gisTotal = totalValue($gisRows);
$sexTotal = totalValue($sexRows);
$mimaropaLocationTotal = totalValue($mimaropaLocationRows);
$incomeTotal = totalValue($incomeRows);
$programTotal = totalValue($programRows);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Analytics</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../assets/style.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>
* {
    box-sizing: border-box;
}

html {
    scroll-behavior: auto !important;
    overflow: hidden !important;
}

body {
    background: #f3f6fb;
    overflow: hidden !important;
    height: 100vh !important;
    margin: 0;
}

.app {
    height: 100vh !important;
    overflow: hidden !important;
}

.main {
    height: 100vh !important;
    overflow: hidden !important;
    min-height: 0 !important;
}

.content {
    padding: 16px !important;
    overflow-y: auto !important;
    overflow-x: hidden !important;
    height: 100vh !important;
    min-height: 0 !important;
    scroll-behavior: auto !important;
    padding-bottom: 48px !important;
}

.analytics-header {
    background: linear-gradient(135deg, #0b2e83, #168fcb);
    color: white;
    padding: 20px;
    border-radius: 14px;
    margin-bottom: 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
}

.analytics-header h1 {
    margin: 0;
    font-size: 28px;
}

.analytics-header p {
    margin: 6px 0 0;
    opacity: .92;
    font-size: 14px;
}

.refresh-btn {
    height: 42px;
    border: 0;
    border-radius: 10px;
    background: rgba(255,255,255,.18);
    color: white;
    font-weight: 900;
    padding: 0 14px;
    display: inline-flex;
    align-items: center;
    gap: 7px;
    cursor: pointer;
    flex-shrink: 0;
}

.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(185px, 1fr));
    gap: 12px;
    margin-bottom: 12px;
}

.card {
    background: white;
    border: 1px solid #d6dce8;
    border-radius: 14px;
    padding: 15px;
    box-shadow: 0 6px 18px rgba(15,23,42,.04);
    min-height: 118px;
}

.card span {
    display: block;
    color: #64748b;
    font-size: 11px;
    font-weight: 900;
    text-transform: uppercase;
}

.card strong {
    display: block;
    font-size: 30px;
    margin-top: 8px;
    color: #0f172a;
}

.card small {
    display: block;
    margin-top: 6px;
    color: #64748b;
    font-weight: 800;
    line-height: 1.3;
}

.dashboard-columns {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    align-items: start;
}

.dash-column {
    display: flex;
    flex-direction: column;
    gap: 12px;
    min-width: 0;
}

.panel {
    background: white;
    border: 1px solid #d6dce8;
    border-radius: 14px;
    padding: 15px;
    box-shadow: 0 6px 18px rgba(15,23,42,.04);
    min-height: 0;
}

.panel h2 {
    margin: 0 0 6px;
    color: #0f172a;
    font-size: 17px;
}

.panel-desc {
    margin: 0 0 12px;
    color: #64748b;
    font-size: 12px;
    font-weight: 700;
}

.chart-layout {
    display: grid;
    grid-template-columns: 145px 1fr;
    gap: 14px;
    align-items: center;
}

.chart-layout.compact-chart {
    grid-template-columns: 110px 1fr;
    gap: 12px;
}

.pie {
    width: 140px;
    height: 140px;
    border-radius: 50%;
    position: relative;
    flex-shrink: 0;
    box-shadow: inset 0 0 0 1px rgba(15,23,42,.08);
}

.compact-chart .pie {
    width: 104px;
    height: 104px;
}

.pie::after {
    content: "";
    position: absolute;
    inset: 36px;
    background: white;
    border-radius: 50%;
    box-shadow: 0 0 0 1px rgba(15,23,42,.05);
}

.compact-chart .pie::after {
    inset: 28px;
}

.pie-center {
    position: absolute;
    inset: 0;
    z-index: 2;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    font-weight: 900;
    color: #0f172a;
    font-size: 21px;
}

.compact-chart .pie-center {
    font-size: 17px;
}

.pie-center small {
    color: #64748b;
    font-size: 10px;
}

.bar-list {
    display: flex;
    flex-direction: column;
    gap: 9px;
}

.bar-title {
    display: flex;
    justify-content: space-between;
    gap: 8px;
    font-size: 12px;
    font-weight: 900;
    color: #334155;
    margin-bottom: 5px;
    line-height: 1.25;
}

.bar-title span:first-child {
    overflow-wrap: anywhere;
}

.bar-title span:last-child {
    white-space: nowrap;
}

.bar-track {
    height: 12px;
    background: #e5e7eb;
    border-radius: 999px;
    overflow: hidden;
}

.bar-fill {
    height: 100%;
    border-radius: 999px;
}

.table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
}

.table th,
.table td {
    padding: 9px;
    border-bottom: 1px solid #e5e7eb;
    text-align: left;
}

.table th {
    background: #f8fafc;
    color: #475569;
    text-transform: uppercase;
    font-size: 10px;
}

.note {
    text-align: right;
    margin-top: 12px;
    color: #64748b;
    font-size: 12px;
    font-weight: 800;
    padding-bottom: 24px;
}

@media(max-width:900px) {
    .dashboard-columns {
        grid-template-columns: 1fr;
    }
}

@media(max-width:700px) {
    .content {
        padding: 12px !important;
        padding-bottom: 48px !important;
    }

    .analytics-header {
        flex-direction: column;
        align-items: flex-start;
    }

    .chart-layout,
    .chart-layout.compact-chart {
        grid-template-columns: 1fr;
    }

    .pie,
    .compact-chart .pie {
        width: 130px;
        height: 130px;
        margin: 0 auto;
    }

    .pie::after,
    .compact-chart .pie::after {
        inset: 34px;
    }
}
</style>
</head>

<body>
<div class="app">

<main class="main">
<section class="content" id="analyticsContent">

<div class="analytics-header">
    <div>
        <h1>Analytics Dashboard</h1>
        <p>
            Current system state for <?php echo h($today); ?>:
            Food Assistance, Cash Relief Assistance, Priority queues, assessment, payout/release, GIS, and beneficiary records.
        </p>
    </div>

    <button class="refresh-btn" onclick="saveAnalyticsScroll(); location.reload();">
        <span class="material-icons">refresh</span>
        Refresh
    </button>
</div>

<div class="cards">
    <div class="card">
        <span>Total Queues Today</span>
        <strong><?php echo $totalQueues; ?></strong>
        <small><?php echo $todayClients; ?> unique queued clients</small>
    </div>

    <div class="card">
        <span>Active Queues</span>
        <strong><?php echo $activeQueues; ?></strong>
        <small><?php echo $activePercent; ?>% still active</small>
    </div>

    <div class="card">
        <span>Paid / Released</span>
        <strong><?php echo $paidQueues; ?></strong>
        <small><?php echo $paidPercent; ?>% completion</small>
    </div>

    <div class="card">
        <span>Approved Amount</span>
        <strong style="font-size:24px;"><?php echo money($approvedAmount); ?></strong>
        <small>locked eligible GIS forms</small>
    </div>

    <div class="card">
        <span>Food Queues</span>
        <strong><?php echo $foodQueues; ?></strong>
        <small>FDAS queues today</small>
    </div>

    <div class="card">
        <span>Cash Relief Queues</span>
        <strong><?php echo $cashReliefQueues; ?></strong>
        <small>CRAS queues today</small>
    </div>

    <div class="card">
        <span>Priority Queues</span>
        <strong><?php echo $priorityQueues; ?></strong>
        <small><?php echo $priorityPercent; ?>% today</small>
    </div>

    <div class="card">
        <span>Regular Queues</span>
        <strong><?php echo $regularQueues; ?></strong>
        <small><?php echo $regularPercent; ?>% food/cash queues</small>
    </div>

    <div class="card">
        <span>Assessment Waiting</span>
        <strong><?php echo $waitingAssessment; ?></strong>
        <small>WAITING_STEP_2</small>
    </div>

    <div class="card">
        <span>Payout Waiting</span>
        <strong><?php echo $waitingPayout; ?></strong>
        <small>WAITING_STEP_3</small>
    </div>

    <div class="card">
        <span>GIS Locked</span>
        <strong><?php echo $gisLocked; ?></strong>
        <small><?php echo $gisLockedPercent; ?>% of today’s queues</small>
    </div>

    <div class="card">
        <span>Total Beneficiaries</span>
        <strong><?php echo $totalBeneficiaries; ?></strong>
        <small>master verifier records</small>
    </div>
</div>

<div class="dashboard-columns">

    <div class="dash-column">

        <div class="panel">
            <h2>Workflow State</h2>
            <p class="panel-desc">Shows current movement from assessment to payout/release.</p>

            <div class="bar-list">
                <?php foreach ($workflowRows as $i => $row): 
                    $value = intval($row['value']);
                    $percent = pct($value, $workflowTotal);
                ?>
                    <div>
                        <div class="bar-title">
                            <span><?php echo h($row['label']); ?></span>
                            <span><?php echo $value; ?> · <?php echo $percent; ?>%</span>
                        </div>

                        <div class="bar-track">
                            <div class="bar-fill" style="width:<?php echo $percent; ?>%;background:<?php echo color($i); ?>"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="panel">
            <h2>Beneficiary Category Segregation</h2>
            <p class="panel-desc">PWD, pregnant, senior, and regular categories from verifier records.</p>

            <div class="chart-layout">
                <div class="pie" style="<?php echo pieStyle($categoryRows); ?>">
                    <div class="pie-center">
                        <?php echo $categoryTotal; ?>
                        <small>records</small>
                    </div>
                </div>

                <div class="bar-list">
                    <?php foreach ($categoryRows as $i => $row): 
                        $value = intval($row['value']);
                        $percent = pct($value, $categoryTotal);
                    ?>
                        <div>
                            <div class="bar-title">
                                <span><?php echo h($row['label']); ?></span>
                                <span><?php echo $value; ?> · <?php echo $percent; ?>% · <?php echo intval($row['queues']); ?> queued today</span>
                            </div>

                            <div class="bar-track">
                                <div class="bar-fill" style="width:<?php echo $percent; ?>%;background:<?php echo color($i); ?>"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="panel">
            <h2>Sex Distribution</h2>
            <p class="panel-desc">Male, female, and unencoded records from beneficiary masterlist.</p>

            <div class="chart-layout compact-chart">
                <div class="pie" style="<?php echo pieStyle($sexRows); ?>">
                    <div class="pie-center">
                        <?php echo $sexTotal; ?>
                        <small>records</small>
                    </div>
                </div>

                <div class="bar-list">
                    <?php if (count($sexRows) > 0): ?>
                        <?php foreach ($sexRows as $i => $row): 
                            $value = intval($row['value']);
                            $percent = pct($value, $sexTotal);
                        ?>
                            <div>
                                <div class="bar-title">
                                    <span><?php echo h($row['label']); ?></span>
                                    <span><?php echo $value; ?> · <?php echo $percent; ?>%</span>
                                </div>

                                <div class="bar-track">
                                    <div class="bar-fill" style="width:<?php echo $percent; ?>%;background:<?php echo color($i); ?>"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div style="color:#64748b;font-weight:800;">No sex data found.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="panel">
            <h2>Program / Assistance Records</h2>
            <p class="panel-desc">Only Food Assistance, Cash Relief Assistance, and Priority records are shown.</p>

            <table class="table">
                <thead>
                    <tr>
                        <th>Program Type</th>
                        <th>Records</th>
                        <th>Share</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($programRows) > 0): ?>
                        <?php foreach ($programRows as $row): ?>
                            <tr>
                                <td><?php echo h($row['label']); ?></td>
                                <td><?php echo intval($row['value']); ?></td>
                                <td><?php echo pct($row['value'], $programTotal); ?>%</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3">No food, cash relief, or priority program records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

    <div class="dash-column">

        <div class="panel">
            <h2>Assistance Type Percentages</h2>
            <p class="panel-desc">Only current allowed queue types: Food, Cash Relief, and Priority.</p>

            <div class="chart-layout">
                <div class="pie" style="<?php echo pieStyle($queueTypeRows); ?>">
                    <div class="pie-center">
                        <?php echo $queueTypeTotal; ?>
                        <small>queues</small>
                    </div>
                </div>

                <div class="bar-list">
                    <?php foreach ($queueTypeRows as $i => $row): 
                        $value = intval($row['value']);
                        $percent = pct($value, $queueTypeTotal);
                    ?>
                        <div>
                            <div class="bar-title">
                                <span><?php echo h($row['label']); ?></span>
                                <span><?php echo $value; ?> · <?php echo $percent; ?>%</span>
                            </div>

                            <div class="bar-track">
                                <div class="bar-fill" style="width:<?php echo $percent; ?>%;background:<?php echo color($i); ?>"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="panel">
            <h2>GIS / Eligibility Result</h2>
            <p class="panel-desc">Draft, approved/locked eligible, and not eligible forms today.</p>

            <div class="chart-layout">
                <div class="pie" style="<?php echo pieStyle($gisRows); ?>">
                    <div class="pie-center">
                        <?php echo $gisTotal; ?>
                        <small>forms</small>
                    </div>
                </div>

                <div class="bar-list">
                    <?php foreach ($gisRows as $i => $row): 
                        $value = intval($row['value']);
                        $percent = pct($value, $gisTotal);
                    ?>
                        <div>
                            <div class="bar-title">
                                <span><?php echo h($row['label']); ?></span>
                                <span><?php echo $value; ?> · <?php echo $percent; ?>%</span>
                            </div>

                            <div class="bar-track">
                                <div class="bar-fill" style="width:<?php echo $percent; ?>%;background:<?php echo color($i); ?>"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="panel">
            <h2>Top MIMAROPA LGU / Location Records</h2>
            <p class="panel-desc">Only records under MIMAROPA / Region IV-B are counted here.</p>

            <div class="bar-list">
                <?php if (count($mimaropaLocationRows) > 0): ?>
                    <?php foreach ($mimaropaLocationRows as $i => $row): 
                        $value = intval($row['value']);
                        $percent = pct($value, $mimaropaLocationTotal);
                    ?>
                        <div>
                            <div class="bar-title">
                                <span><?php echo h($row['label']); ?></span>
                                <span><?php echo $value; ?> · <?php echo $percent; ?>%</span>
                            </div>

                            <div class="bar-track">
                                <div class="bar-fill" style="width:<?php echo $percent; ?>%;background:<?php echo color($i); ?>"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div style="color:#64748b;font-weight:800;">No MIMAROPA records found.</div>
                <?php endif; ?>
            </div>
        </div>

        <div class="panel">
            <h2>Source of Income Today</h2>
            <p class="panel-desc">GIS/Assessment income source, usually BSNS, SLRY, or NONE.</p>

            <table class="table">
                <thead>
                    <tr>
                        <th>Source</th>
                        <th>Count</th>
                        <th>Share</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($incomeRows) > 0): ?>
                        <?php foreach ($incomeRows as $row): ?>
                            <tr>
                                <td><?php echo h($row['label']); ?></td>
                                <td><?php echo intval($row['value']); ?></td>
                                <td><?php echo pct($row['value'], $incomeTotal); ?>%</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3">No encoded GIS source of income yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>

</div>

<div class="note">
    Auto-refresh every 20 seconds. Scroll position is preserved. Last loaded: <?php echo h($loadedAt); ?>
</div>

</section>
</main>

<?php include('sidebar.php'); ?>

</div>

<script>
const ANALYTICS_SCROLL_KEY = 'analytics_nested_scroll_v4';

if ('scrollRestoration' in history) {
    history.scrollRestoration = 'manual';
}

function getScrollBox() {
    return document.getElementById('analyticsContent');
}

function saveAnalyticsScroll() {
    const box = getScrollBox();
    if (!box) return;

    sessionStorage.setItem(ANALYTICS_SCROLL_KEY, String(box.scrollTop || 0));
}

function restoreAnalyticsScroll() {
    const box = getScrollBox();
    if (!box) return;

    const saved = sessionStorage.getItem(ANALYTICS_SCROLL_KEY);
    if (saved === null) return;

    const target = parseInt(saved, 10) || 0;

    requestAnimationFrame(function () {
        box.scrollTop = target;
    });
}

window.addEventListener('DOMContentLoaded', restoreAnalyticsScroll);
window.addEventListener('load', restoreAnalyticsScroll);

document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') {
        saveAnalyticsScroll();
    }
});

window.addEventListener('beforeunload', saveAnalyticsScroll);
window.addEventListener('pagehide', saveAnalyticsScroll);

setTimeout(function () {
    saveAnalyticsScroll();
    location.reload();
}, 20000);
</script>

</body>
</html>