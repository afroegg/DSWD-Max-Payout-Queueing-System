<?php
include('../auth/check.php');
include('../config/db.php');

$conn->query("
    CREATE TABLE IF NOT EXISTS system_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value VARCHAR(255) NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
");

$conn->query("
    INSERT IGNORE INTO system_settings (setting_key, setting_value)
    VALUES ('counter_assignment_mode', 'automatic')
");

function h($value) {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function fullName($row) {
    return trim(
        ($row['last_name'] ?? '') . ', ' .
        ($row['first_name'] ?? '') . ' ' .
        ($row['middle_name'] ?? '') . ' ' .
        ($row['ext_name'] ?? '')
    );
}

function getSetting($conn, $key, $default = '') {
    $stmt = $conn->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ? LIMIT 1");
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc()['setting_value'];
    }

    return $default;
}

function counterDropdown($min, $max) {
    $html = '<select name="counter_number" class="counter-select" title="Counter">';

    for ($i = $min; $i <= $max; $i++) {
        $html .= '<option value="' . $i . '">C' . $i . '</option>';
    }

    $html .= '</select>';
    return $html;
}

$counterMode = getSetting($conn, 'counter_assignment_mode', 'automatic');

$sql = "
    SELECT 
        q.id,
        q.queue_number,
        q.queue_type,
        q.workflow_status,
        q.counter_number,
        q.table_number,
        b.first_name,
        b.middle_name,
        b.last_name,
        b.ext_name,
        b.beneficiary_code,
        b.age,
        b.sex,
        b.barangay,
        b.lgu,
        e.form_locked,
        e.eligibility_status,
        e.approved_cash_amount
    FROM queue_entries q
    JOIN beneficiaries b ON b.id = q.beneficiary_id
    LEFT JOIN eligibility_forms e ON e.queue_entry_id = q.id
    WHERE DATE(q.transaction_date) = CURDATE()
    AND q.workflow_status IN ('WAITING_STEP_2', 'CALLED_STEP_2', 'HELD')
    ORDER BY 
        CASE 
            WHEN q.workflow_status = 'CALLED_STEP_2' THEN 0
            WHEN q.workflow_status = 'HELD' THEN 1
            WHEN q.queue_type = 'priority' THEN 2
            ELSE 3
        END,
        q.id ASC
";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Assessment</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css">

<style>
* {
    box-sizing: border-box;
}

body {
    background: #f3f6fb;
}

.verifier-content {
    padding: 20px;
    flex: 1;
    min-height: 0;
    overflow: hidden;
    display: flex;
    flex-direction: column;
}

.page-header-card {
    background: #fff;
    border: 1px solid #d6dce8;
    border-radius: 12px;
    padding: 18px 20px;
    margin-bottom: 14px;
    flex-shrink: 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
}

.page-header-card h1 {
    margin: 0;
    font-size: 24px;
    color: #111827;
}

.page-header-card p {
    margin: 6px 0 0;
    font-size: 14px;
    color: #6b7280;
}

.toolbar {
    display: grid;
    grid-template-columns: 1fr 150px 170px 120px auto;
    gap: 10px;
    margin-bottom: 14px;
    flex-shrink: 0;
    align-items: center;
}

.toolbar input,
.toolbar select {
    height: 42px;
    padding: 0 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 14px;
    background: white;
    outline: none;
}

.icon-link {
    height: 42px;
    min-width: 42px;
    border-radius: 8px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: #374151;
    color: white;
    text-decoration: none;
    border: none;
    cursor: pointer;
}

.sheet-card {
    background: white;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    overflow: hidden;
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
}

.table-scroll {
    width: 100%;
    overflow: auto;
    flex: 1;
    min-height: 0;
}

.verifier-table {
    width: 100%;
    min-width: 1030px;
    border-collapse: collapse;
    font-size: 13px;
}

.verifier-table th {
    background: #dbeafe;
    color: #111827;
    font-weight: 800;
    text-align: left;
    border-bottom: 1px solid #b6c3d5;
    padding: 11px 10px;
    white-space: nowrap;
    position: sticky;
    top: 0;
    z-index: 3;
}

.verifier-table td {
    border-bottom: 1px solid #e5e7eb;
    padding: 10px;
    vertical-align: middle;
    background: #fff;
    white-space: nowrap;
}

.verifier-table tbody tr:nth-child(even) td {
    background: #f9fafb;
}

.verifier-table tbody tr:hover td {
    background: #eef6ff;
}

.row-priority td {
    background: #fff7ed !important;
}

.row-held td {
    background: #fef2f2 !important;
}

.row-number {
    text-align: center;
    font-weight: 800;
    color: #475569;
}

.queue-number {
    font-weight: 900;
    color: #1d4ed8;
}

.priority-queue-number {
    color: #c2410c !important;
}

.client-name {
    font-weight: 800;
    color: #111827;
}

.muted-small {
    color: #6b7280;
    font-size: 12px;
    display: block;
    margin-top: 2px;
}

.priority-label,
.regular-label {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 900;
    margin-left: 6px;
}

.priority-label {
    background: #fed7aa;
    color: #9a3412;
}

.regular-label {
    background: #e5e7eb;
    color: #374151;
}

.status-badge {
    display: inline-block;
    min-width: 116px;
    text-align: center;
    padding: 6px 10px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 900;
    text-transform: uppercase;
}

.status-waiting {
    background: #fef3c7;
    color: #92400e;
}

.status-called {
    background: #dbeafe;
    color: #1e40af;
}

.status-gis {
    background: #dcfce7;
    color: #166534;
}

.status-held {
    background: #fee2e2;
    color: #991b1b;
}

.counter-chip {
    display: block;
    margin-top: 4px;
    color: #0b2e83;
    font-size: 12px;
    font-weight: 900;
}

.amount-chip {
    display: block;
    margin-top: 3px;
    color: #166534;
    font-size: 12px;
    font-weight: 900;
}

.action-group {
    display: flex;
    gap: 6px;
    justify-content: center;
    align-items: center;
}

.action-group form {
    margin: 0;
    display: inline-flex;
    gap: 6px;
    align-items: center;
}

.counter-select {
    height: 36px;
    width: 58px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    background: white;
    font-size: 12px;
    font-weight: 900;
    color: #111827;
    padding: 0 5px;
}

.icon-btn {
    width: 36px;
    height: 36px;
    border: none;
    border-radius: 8px;
    color: white;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
}

.icon-btn .material-icons {
    font-size: 19px;
}

.btn-ok {
    background: #16a34a;
}

.btn-hold {
    background: #f97316;
}

.btn-resume {
    background: #0ea5e9;
}

.btn-cancel {
    background: #dc2626;
}

.btn-gis {
    background: #2563eb;
}

.btn-send-confirmation {
    background: #0f766e;
}

.icon-btn:disabled,
.off {
    background: #9ca3af !important;
    cursor: not-allowed;
    opacity: .55;
    pointer-events: none;
}

.footer-note {
    padding: 10px 12px;
    font-size: 12px;
    color: #6b7280;
    background: #f9fafb;
    border-top: 1px solid #d1d5db;
    display: flex;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
    flex-shrink: 0;
}

.pagination {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 12px;
    border-top: 1px solid #d1d5db;
    background: #fff;
    flex-shrink: 0;
}

.page-btn {
    height: 34px;
    min-width: 34px;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
    background: white;
    cursor: pointer;
    font-weight: 800;
}

.page-btn:disabled {
    opacity: .45;
    cursor: not-allowed;
}

.page-info {
    font-size: 13px;
    color: #475569;
    font-weight: 700;
}

.empty-state {
    text-align: center;
    padding: 22px;
    color: #6b7280;
    font-weight: 800;
}

.system-toast {
    position: fixed;
    top: 24px;
    right: 24px;
    min-width: 280px;
    max-width: 420px;
    background: #ffffff;
    border-left: 6px solid #16a34a;
    border-radius: 12px;
    padding: 14px 16px;
    box-shadow: 0 12px 35px rgba(15, 23, 42, 0.22);
    display: none;
    align-items: flex-start;
    gap: 10px;
    z-index: 99999;
    animation: toastSlide .25s ease;
}

.system-toast.show {
    display: flex;
}

.system-toast.error {
    border-left-color: #dc2626;
}

.system-toast .material-icons {
    color: #16a34a;
    font-size: 24px;
}

.system-toast.error .material-icons {
    color: #dc2626;
}

.toast-message {
    font-size: 14px;
    font-weight: 800;
    color: #111827;
    line-height: 1.4;
}

@keyframes toastSlide {
    from {
        opacity: 0;
        transform: translateY(-12px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media(max-width:1000px) {
    .toolbar {
        grid-template-columns: 1fr 1fr;
    }

    .verifier-table {
        min-width: 980px;
    }
}

@media(max-width:700px) {
    .toolbar {
        grid-template-columns: 1fr;
    }

    .system-toast {
        left: 16px;
        right: 16px;
        top: 16px;
        min-width: unset;
        max-width: unset;
    }
}
</style>
</head>

<body>
<div class="app">
<main class="main">
<section class="verifier-content">

<div class="page-header-card">
    <div>
        <h1>Assessment [Step 2]</h1>
        <p>Counter mode: <?php echo strtoupper(h($counterMode)); ?>. Assessment counters use Counter 1 to Counter 5.</p>
    </div>

    <button type="button" class="icon-link" onclick="location.reload()" title="Refresh">
        <span class="material-icons">refresh</span>
    </button>
</div>

<div class="toolbar">
    <input id="s" placeholder="Search name, queue, barangay, LGU...">

    <select id="t">
        <option value="">All Types</option>
        <option value="priority">PRIO Only</option>
        <option value="regular">PAL Only</option>
    </select>

    <select id="st">
        <option value="">All Status</option>
        <option value="WAITING_STEP_2">Waiting Step 2</option>
        <option value="CALLED_STEP_2">Called Step 2</option>
        <option value="HELD">Held</option>
    </select>

    <select id="rowsPerPage">
        <option value="10">10 rows</option>
        <option value="25" selected>25 rows</option>
        <option value="50">50 rows</option>
        <option value="100">100 rows</option>
    </select>

    <button type="button" class="icon-link" onclick="location.reload()" title="Refresh">
        <span class="material-icons">refresh</span>
    </button>
</div>

<div class="sheet-card">
<div class="table-scroll">
<table class="verifier-table">
<thead>
<tr>
    <th style="width:55px;text-align:center;">#</th>
    <th style="width:135px;">Queue No.</th>
    <th>Name</th>
    <th>Barangay</th>
    <th style="width:70px;">Age</th>
    <th style="width:70px;">Sex</th>
    <th>LGU</th>
    <th style="width:145px;">Status</th>
    <th style="width:260px;text-align:center;">Actions</th>
</tr>
</thead>

<tbody id="rows">
<?php if ($result && $result->num_rows > 0): ?>
    <?php $n = 1; ?>
    <?php while ($r = $result->fetch_assoc()): ?>
        <?php
        $isPrio = $r['queue_type'] === 'priority';
        $isHeld = $r['workflow_status'] === 'HELD';
        $isCalled = $r['workflow_status'] === 'CALLED_STEP_2';
        $isWaiting = $r['workflow_status'] === 'WAITING_STEP_2';
        $counter = intval($r['counter_number'] ?: $r['table_number'] ?: 0);
        $gis = intval($r['form_locked'] ?? 0) === 1;
        $statusClass = $isHeld ? 'status-held' : ($isCalled ? 'status-called' : ($gis ? 'status-gis' : 'status-waiting'));
        ?>

        <tr class="data <?php echo $isHeld ? 'row-held' : ($isPrio ? 'row-priority' : ''); ?>"
            data-type="<?php echo h($r['queue_type']); ?>"
            data-status="<?php echo h($r['workflow_status']); ?>">

            <td class="row-number"><?php echo $n++; ?></td>

            <td class="queue-number <?php echo $isPrio ? 'priority-queue-number' : ''; ?>">
                <?php echo h($r['queue_number']); ?>
                <?php echo $isPrio ? '<span class="priority-label">PRIO</span>' : '<span class="regular-label">PAL</span>'; ?>
            </td>

            <td>
                <span class="client-name"><?php echo h(fullName($r)); ?></span>
                <span class="muted-small"><?php echo h($r['beneficiary_code'] ?? 'No code'); ?></span>
            </td>

            <td><?php echo h($r['barangay']); ?></td>
            <td><?php echo intval($r['age']); ?></td>
            <td><?php echo h($r['sex']); ?></td>
            <td><?php echo h($r['lgu']); ?></td>

            <td>
                <span class="status-badge <?php echo $statusClass; ?>">
                    <?php echo h($r['workflow_status']); ?>
                </span>

                <?php if ($isCalled && $counter > 0): ?>
                    <span class="counter-chip">Counter <?php echo $counter; ?></span>
                <?php endif; ?>

                <span class="amount-chip">
                    <?php echo $gis ? 'GIS saved' : 'No GIS'; ?>
                </span>
            </td>

            <td>
                <div class="action-group">

                    <?php if ($isWaiting): ?>

                        <form method="POST" action="../api/call_queue.php">
                            <input type="hidden" name="queue_id" value="<?php echo intval($r['id']); ?>">
                            <input type="hidden" name="redirect" value="../staff/assessment_screen.php">

                            <?php if ($counterMode === 'manual'): ?>
                                <?php echo counterDropdown(1, 5); ?>
                            <?php endif; ?>

                            <button class="icon-btn btn-ok" title="<?php echo $counterMode === 'manual' ? 'Call to Selected Counter' : 'Call to Auto Counter'; ?>">
                                <span class="material-icons">campaign</span>
                            </button>
                        </form>

                        <form method="POST" action="../api/hold_queue.php">
                            <input type="hidden" name="queue_id" value="<?php echo intval($r['id']); ?>">
                            <input type="hidden" name="redirect" value="../staff/assessment_screen.php">
                            <button class="icon-btn btn-hold" title="Hold">
                                <span class="material-icons">pause</span>
                            </button>
                        </form>

                        <form method="POST" action="../api/cancel_queue.php">
                            <input type="hidden" name="queue_id" value="<?php echo intval($r['id']); ?>">
                            <input type="hidden" name="redirect" value="../staff/assessment_screen.php">
                            <button class="icon-btn btn-cancel" title="Cancel">
                                <span class="material-icons">close</span>
                            </button>
                        </form>

                    <?php elseif ($isCalled): ?>

                        <a class="icon-btn btn-gis" href="eligibility_form.php?queue_id=<?php echo intval($r['id']); ?>" title="Open GIS Form">
                            <span class="material-icons">description</span>
                        </a>

                        <form method="POST" action="../api/mark_assessed.php">
                            <input type="hidden" name="queue_id" value="<?php echo intval($r['id']); ?>">
                            <input type="hidden" name="redirect" value="../staff/assessment_screen.php">
                            <button class="icon-btn btn-send-confirmation <?php echo !$gis ? 'off' : ''; ?>" title="Send to Confirmation">
                                <span class="material-icons">send</span>
                            </button>
                        </form>

                        <form method="POST" action="../api/hold_queue.php">
                            <input type="hidden" name="queue_id" value="<?php echo intval($r['id']); ?>">
                            <input type="hidden" name="redirect" value="../staff/assessment_screen.php">
                            <button class="icon-btn btn-hold" title="Hold">
                                <span class="material-icons">pause</span>
                            </button>
                        </form>

                        <form method="POST" action="../api/cancel_queue.php">
                            <input type="hidden" name="queue_id" value="<?php echo intval($r['id']); ?>">
                            <input type="hidden" name="redirect" value="../staff/assessment_screen.php">
                            <button class="icon-btn btn-cancel" title="Cancel">
                                <span class="material-icons">close</span>
                            </button>
                        </form>

                    <?php elseif ($isHeld): ?>

                        <form method="POST" action="../api/resume_queue.php">
                            <input type="hidden" name="queue_id" value="<?php echo intval($r['id']); ?>">
                            <input type="hidden" name="resume_to" value="WAITING_STEP_2">
                            <input type="hidden" name="redirect" value="../staff/assessment_screen.php">
                            <button class="icon-btn btn-resume" title="Resume Assessment">
                                <span class="material-icons">play_arrow</span>
                            </button>
                        </form>

                        <form method="POST" action="../api/cancel_queue.php">
                            <input type="hidden" name="queue_id" value="<?php echo intval($r['id']); ?>">
                            <input type="hidden" name="redirect" value="../staff/assessment_screen.php">
                            <button class="icon-btn btn-cancel" title="Cancel">
                                <span class="material-icons">close</span>
                            </button>
                        </form>

                    <?php endif; ?>

                </div>
            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr class="empty-state-row">
        <td colspan="9" class="empty-state">No beneficiaries found.</td>
    </tr>
<?php endif; ?>
</tbody>
</table>
</div>

<div class="pagination" id="p"></div>

<div class="footer-note">
    <span id="recordInfo">Showing records...</span>
    <span id="lastUpdated">Last updated: --</span>
</div>

</div>

</section>
</main>

<?php include('sidebar.php'); ?>

</div>

<div id="systemToast" class="system-toast">
    <span id="toastIcon" class="material-icons">check_circle</span>
    <div id="toastMessage" class="toast-message"></div>
</div>

<script>
const rows = [...document.querySelectorAll('.data')];
const s = document.getElementById('s');
const t = document.getElementById('t');
const st = document.getElementById('st');
const rpp = document.getElementById('rowsPerPage');
const p = document.getElementById('p');
const info = document.getElementById('recordInfo');
const last = document.getElementById('lastUpdated');

let page = 1;

function filteredRows() {
    let search = s.value.toLowerCase().trim();
    let type = t.value;
    let status = st.value;

    return rows.filter(row => {
        return (!type || row.dataset.type === type) &&
               (!status || row.dataset.status === status) &&
               row.innerText.toLowerCase().includes(search);
    });
}

function apply() {
    if (rows.length === 0) {
        p.innerHTML = '';
        info.textContent = 'Showing 0 of 0 filtered records (0 total)';
        last.textContent = 'Last updated: ' + new Date().toLocaleTimeString();
        return;
    }

    let visible = filteredRows();
    let per = parseInt(rpp.value, 10);
    let pages = Math.max(1, Math.ceil(visible.length / per));

    if (page > pages) page = pages;

    rows.forEach(row => row.style.display = 'none');
    visible.slice((page - 1) * per, page * per).forEach(row => row.style.display = '');

    p.innerHTML = `
        <button class="page-btn" ${page === 1 ? 'disabled' : ''} onclick="page=1;apply()">«</button>
        <button class="page-btn" ${page === 1 ? 'disabled' : ''} onclick="page--;apply()">‹</button>
        <span class="page-info">Page ${page} of ${pages}</span>
        <button class="page-btn" ${page === pages ? 'disabled' : ''} onclick="page++;apply()">›</button>
        <button class="page-btn" ${page === pages ? 'disabled' : ''} onclick="page=${pages};apply()">»</button>
    `;

    let start = visible.length ? (page - 1) * per + 1 : 0;
    let end = Math.min(page * per, visible.length);

    info.textContent = `Showing ${start}-${end} of ${visible.length} filtered records (${rows.length} total)`;
    last.textContent = 'Last updated: ' + new Date().toLocaleTimeString();
}

[s, t, st, rpp].forEach(el => {
    el.addEventListener('input', () => {
        page = 1;
        apply();
    });

    el.addEventListener('change', () => {
        page = 1;
        apply();
    });
});

function showSystemToast(message, type = 'success') {
    const toast = document.getElementById('systemToast');
    const toastIcon = document.getElementById('toastIcon');
    const toastMessage = document.getElementById('toastMessage');

    if (!toast || !toastIcon || !toastMessage) return;

    toast.classList.remove('success', 'error', 'show');
    toast.classList.add(type);

    toastIcon.textContent = type === 'error' ? 'error' : 'check_circle';
    toastMessage.textContent = message;

    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function checkUrlToast() {
    const toastParams = new URLSearchParams(window.location.search);
    const toastType = toastParams.get('toast_type');
    const toastMsg = toastParams.get('toast_msg');

    if (toastMsg) {
        showSystemToast(toastMsg, toastType || 'success');

        toastParams.delete('toast_type');
        toastParams.delete('toast_msg');

        const cleanUrl =
            window.location.pathname +
            (toastParams.toString() ? '?' + toastParams.toString() : '');

        window.history.replaceState({}, document.title, cleanUrl);
    }
}

checkUrlToast();
apply();
</script>

</body>
</html>