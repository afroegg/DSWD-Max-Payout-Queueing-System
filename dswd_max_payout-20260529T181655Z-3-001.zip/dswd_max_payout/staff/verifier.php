<?php
include('../auth/check.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Verify Beneficiaries</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css">

<style>
* {
    box-sizing: border-box;
}

body {
    background: #f3f6fb;
}

.verifier-content {
    padding: 20px;
    flex: 1;
    min-height: 0;
    overflow: hidden;
    display: flex;
    flex-direction: column;
}

.page-header-card {
    background: #fff;
    border: 1px solid #d6dce8;
    border-radius: 12px;
    padding: 18px 20px;
    margin-bottom: 14px;
    flex-shrink: 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
}

.page-header-card h1 {
    margin: 0;
    font-size: 24px;
    color: #111827;
}

.page-header-card p {
    margin: 6px 0 0;
    font-size: 14px;
    color: #6b7280;
}

.header-actions {
    display: flex;
    gap: 8px;
    align-items: center;
    flex-wrap: wrap;
}

.header-btn {
    height: 42px;
    border: 0;
    border-radius: 10px;
    font-weight: 900;
    padding: 0 14px;
    display: inline-flex;
    align-items: center;
    gap: 7px;
    cursor: pointer;
    text-decoration: none;
}

.upload-main {
    background: #168fcb;
    color: white;
}

.refresh-main {
    background: #374151;
    color: white;
}

.import-result {
    display: none;
    margin-bottom: 14px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 12px;
    font-size: 13px;
    font-weight: 800;
    color: #334155;
    flex-shrink: 0;
}

.progress-title {
    display: flex;
    justify-content: space-between;
    margin-bottom: 8px;
    font-weight: 900;
}

.progress-track {
    height: 13px;
    background: #e5e7eb;
    border-radius: 999px;
    overflow: hidden;
    border: 1px solid #cbd5e1;
}

.progress-fill {
    height: 100%;
    background: #168fcb;
    border-radius: 999px;
    transition: width .25s ease;
}

.import-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 8px;
    margin-top: 10px;
    text-align: center;
}

.import-stat {
    border-radius: 8px;
    padding: 8px;
}

.import-stat b {
    font-size: 18px;
}

.toolbar {
    display: grid;
    grid-template-columns: 1fr 150px 170px 120px auto;
    gap: 10px;
    margin-bottom: 14px;
    flex-shrink: 0;
    align-items: center;
}

.toolbar input,
.toolbar select {
    height: 42px;
    padding: 0 12px;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    font-size: 14px;
    background: white;
    outline: none;
}

.icon-link {
    height: 42px;
    min-width: 42px;
    border-radius: 8px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: #374151;
    color: white;
    text-decoration: none;
    border: none;
    cursor: pointer;
}

.sheet-card {
    background: white;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    overflow: hidden;
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
}

.table-scroll {
    width: 100%;
    overflow: auto;
    flex: 1;
    min-height: 0;
}

.verifier-table {
    width: 100%;
    min-width: 1030px;
    border-collapse: collapse;
    font-size: 13px;
}

.verifier-table th {
    background: #dbeafe;
    color: #111827;
    font-weight: 800;
    text-align: left;
    border-bottom: 1px solid #b6c3d5;
    padding: 11px 10px;
    white-space: nowrap;
    position: sticky;
    top: 0;
    z-index: 3;
}

.verifier-table td {
    border-bottom: 1px solid #e5e7eb;
    padding: 10px;
    vertical-align: middle;
    background: #fff;
    white-space: nowrap;
}

.verifier-table tbody tr:nth-child(even) td {
    background: #f9fafb;
}

.verifier-table tbody tr:hover td {
    background: #eef6ff;
}

.row-priority td {
    background: #fff7ed !important;
}

.row-number {
    text-align: center;
    font-weight: 800;
    color: #475569;
}

.client-name {
    font-weight: 800;
    color: #111827;
}

.muted-small {
    color: #6b7280;
    font-size: 12px;
    display: block;
    margin-top: 2px;
}

.queue-number {
    font-weight: 900;
    color: #1d4ed8;
}

.priority-queue-number {
    color: #c2410c !important;
}

.priority-label {
    display: inline-block;
    background: #fed7aa;
    color: #9a3412;
    padding: 3px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 900;
    margin-left: 6px;
}

.category-badge {
    display: inline-block;
    margin-left: 6px;
    padding: 3px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 900;
}

.cat-pwd {
    background: #f5f3ff;
    color: #6d28d9;
}

.cat-pregnant {
    background: #fdf2f8;
    color: #be185d;
}

.cat-senior {
    background: #eff6ff;
    color: #1d4ed8;
}

.cat-regular {
    background: #e5e7eb;
    color: #374151;
}

.status-badge {
    display: inline-block;
    min-width: 116px;
    text-align: center;
    padding: 6px 10px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 900;
    text-transform: uppercase;
}

.status-step-2 {
    background: #fef3c7;
    color: #92400e;
}

.status-called-2 {
    background: #fde68a;
    color: #78350f;
}

.status-step-3 {
    background: #dbeafe;
    color: #1e40af;
}

.status-called-3 {
    background: #bfdbfe;
    color: #1e3a8a;
}

.status-paid {
    background: #dcfce7;
    color: #166534;
}

.status-cancelled {
    background: #fee2e2;
    color: #991b1b;
}

.status-none {
    background: #e5e7eb;
    color: #374151;
}

.action-group {
    display: flex;
    gap: 6px;
    justify-content: center;
    align-items: center;
}

.action-group form {
    margin: 0;
    display: inline-flex;
    align-items: center;
}

.icon-btn {
    width: 36px;
    height: 36px;
    border: none;
    border-radius: 8px;
    color: white;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
}

.icon-btn .material-icons {
    font-size: 19px;
}

.btn-view {
    background: #2563eb;
}

.btn-regular {
    background: #16a34a;
}

.btn-priority {
    background: #f97316;
}

.btn-regenerate {
    background: #64748b;
}

.regen-choice-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
    margin-top: 18px;
}

.regen-choice-form {
    margin: 0;
}

.regen-choice-btn {
    width: 100%;
    min-height: 105px;
    border: none;
    border-radius: 14px;
    color: white;
    font-weight: 1000;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    font-size: 18px;
    gap: 8px;
}

.regen-choice-btn .material-icons {
    font-size: 34px;
}

.regen-regular {
    background: #16a34a;
}

.regen-priority {
    background: #f97316;
}

.btn-remove {
    background: #991b1b;
}

.icon-btn:disabled {
    background: #9ca3af;
    cursor: not-allowed;
    opacity: .55;
}

.footer-note {
    padding: 10px 12px;
    font-size: 12px;
    color: #6b7280;
    background: #f9fafb;
    border-top: 1px solid #d1d5db;
    display: flex;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
    flex-shrink: 0;
}

.pagination {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 12px;
    border-top: 1px solid #d1d5db;
    background: #fff;
    flex-shrink: 0;
}

.page-btn {
    height: 34px;
    min-width: 34px;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
    background: white;
    cursor: pointer;
    font-weight: 800;
}

.page-btn:disabled {
    opacity: .45;
    cursor: not-allowed;
}

.page-info {
    font-size: 13px;
    color: #475569;
    font-weight: 700;
}

.empty-state,
.loading-text {
    text-align: center;
    padding: 22px;
    color: #6b7280;
    font-weight: 800;
}

.modal-overlay {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(15,23,42,.55);
    z-index: 9999;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.modal-box {
    width: 760px;
    max-width: 96%;
    background: #fff;
    border-radius: 14px;
    padding: 24px;
    box-shadow: 0 14px 40px rgba(0,0,0,.25);
}

.modal-box h2 {
    margin: 0;
    color: #111827;
    font-size: 22px;
}

.modal-box p {
    margin: 8px 0 20px;
    color: #4b5563;
    font-size: 14px;
}

.details-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
    margin: 18px 0;
}

.detail-item {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 10px;
}

.detail-item span {
    display: block;
    font-size: 11px;
    color: #64748b;
    font-weight: 800;
    text-transform: uppercase;
    margin-bottom: 4px;
}

.detail-item strong {
    display: block;
    color: #111827;
    font-size: 13px;
    word-break: break-word;
}

.detail-priority {
    background: #fff7ed;
    border-color: #fed7aa;
}

.modal-cancel {
    width: 100%;
    height: 42px;
    border: none;
    border-radius: 10px;
    background: #e5e7eb;
    color: #111827;
    font-weight: 900;
    cursor: pointer;
}

.drop-hint {
    border: 2px dashed #93c5fd;
    background: #eff6ff;
}

.system-toast {
    position: fixed;
    top: 24px;
    right: 24px;
    min-width: 280px;
    max-width: 420px;
    background: #ffffff;
    border-left: 6px solid #16a34a;
    border-radius: 12px;
    padding: 14px 16px;
    box-shadow: 0 12px 35px rgba(15, 23, 42, 0.22);
    display: none;
    align-items: flex-start;
    gap: 10px;
    z-index: 99999;
    animation: toastSlide .25s ease;
}

.system-toast.show {
    display: flex;
}

.system-toast.error {
    border-left-color: #dc2626;
}

.system-toast .material-icons {
    color: #16a34a;
    font-size: 24px;
}

.system-toast.error .material-icons {
    color: #dc2626;
}

.toast-message {
    font-size: 14px;
    font-weight: 800;
    color: #111827;
    line-height: 1.4;
}

@keyframes toastSlide {
    from {
        opacity: 0;
        transform: translateY(-12px);
    }

    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media(max-width:1000px) {
    .toolbar {
        grid-template-columns: 1fr 1fr;
    }

    .verifier-table {
        min-width: 980px;
    }
}

@media(max-width:700px) {
    .page-header-card {
        flex-direction: column;
        align-items: flex-start;
    }

    .toolbar {
        grid-template-columns: 1fr;
    }

    .details-grid {
        grid-template-columns: 1fr;
    }

    .system-toast {
        left: 16px;
        right: 16px;
        top: 16px;
        min-width: unset;
        max-width: unset;
    }
}
</style>
</head>

<body>
<div class="app">

<main class="main">
<section class="verifier-content">

<div class="page-header-card">
    <div>
        <h1>Verify [Step 1]</h1>
        <p>Upload Excel or CSV data, verify beneficiaries, then generate Regular or Priority queue numbers.</p>
    </div>

    <div class="header-actions">
        <button type="button" class="header-btn upload-main" onclick="chooseFile()">
            <span class="material-icons">file_upload</span>
            Upload Excel Data
        </button>

        <button type="button" class="header-btn refresh-main" onclick="manualRefresh()">
            <span class="material-icons">refresh</span>
            Refresh
        </button>
    </div>
</div>

<input type="file" id="importFile" accept=".csv,.xlsx,.xls,.xlsm,.ods" hidden>

<div class="import-result" id="importResult"></div>

<div class="toolbar">
    <input type="text" id="searchInput" placeholder="Search name, queue, barangay, LGU...">

    <select id="typeFilter">
        <option value="all">All Types</option>
        <option value="priority">PRIO Only</option>
        <option value="regular">Regular Only</option>
        <option value="none">No Queue</option>
    </select>

    <select id="statusFilter">
        <option value="all">All Status</option>
        <option value="WAITING_STEP_2">Waiting Step 2</option>
        <option value="CALLED_STEP_2">Called Step 2</option>
        <option value="WAITING_STEP_3">Waiting Step 3</option>
        <option value="CALLED_STEP_3">Called Step 3</option>
        <option value="PAID">Paid</option>
        <option value="CANCELLED">Cancelled</option>
        <option value="none">No Queue</option>
    </select>

    <select id="rowsPerPage">
        <option value="10">10 rows</option>
        <option value="25" selected>25 rows</option>
        <option value="50">50 rows</option>
        <option value="100">100 rows</option>
    </select>

    <button type="button" class="icon-link" onclick="manualRefresh()" title="Refresh">
        <span class="material-icons">refresh</span>
    </button>
</div>

<div class="sheet-card" id="sheetCard">
    <div class="table-scroll">
        <table class="verifier-table">
            <thead>
                <tr>
                    <th style="width:55px;text-align:center;">#</th>
                    <th style="width:140px;">Queue No.</th>
                    <th>Name</th>
                    <th>Barangay</th>
                    <th style="width:70px;">Age</th>
                    <th style="width:70px;">Sex</th>
                    <th>LGU</th>
                    <th style="width:145px;">Status</th>
                    <th style="width:190px;text-align:center;">Actions</th>
                </tr>
            </thead>

            <tbody id="beneficiaryRows">
                <tr>
                    <td colspan="9" class="loading-text">Loading beneficiaries...</td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="pagination" id="paginationControls"></div>

    <div class="footer-note">
        <span id="recordInfo">Showing records...</span>
        <span id="lastUpdated">Last updated: --</span>
    </div>
</div>

</section>
</main>

<?php include('sidebar.php'); ?>

</div>

<div id="detailsModal" class="modal-overlay">
    <div class="modal-box">
        <h2>Beneficiary Details</h2>
        <p>Complete beneficiary record view.</p>

        <div class="details-grid" id="detailsGrid"></div>

        <button type="button" class="modal-cancel" onclick="closeDetailsModal()">Close</button>
    </div>
</div>

<div id="regenModal" class="modal-overlay">
    <div class="modal-box" style="width:480px;text-align:center;">
        <h2>Regenerate Queue Type</h2>
        <p>Choose the new queue type for this beneficiary.</p>

        <div class="regen-choice-grid">
            <form method="POST" action="../api/regenerate_queue.php" class="regen-choice-form">
                <input type="hidden" name="beneficiary_id" id="regenRegularBeneficiaryId">
                <input type="hidden" name="new_queue_type" value="regular">

                <button type="submit" class="regen-choice-btn regen-regular">
                    <span class="material-icons">groups</span>
                    Regular
                </button>
            </form>

            <form method="POST" action="../api/regenerate_queue.php" class="regen-choice-form">
                <input type="hidden" name="beneficiary_id" id="regenPriorityBeneficiaryId">
                <input type="hidden" name="new_queue_type" value="priority">

                <button type="submit" class="regen-choice-btn regen-priority">
                    <span class="material-icons">priority_high</span>
                    Priority
                </button>
            </form>
        </div>

        <button type="button" class="modal-cancel" style="margin-top:14px;" onclick="closeRegenModal()">Cancel</button>
    </div>
</div>

<div id="systemToast" class="system-toast">
    <span id="toastIcon" class="material-icons">check_circle</span>
    <div id="toastMessage" class="toast-message"></div>
</div>

<script>
(function () {
    const searchInput = document.getElementById('searchInput');
    const typeFilter = document.getElementById('typeFilter');
    const statusFilter = document.getElementById('statusFilter');
    const rowsPerPage = document.getElementById('rowsPerPage');
    const tableBody = document.getElementById('beneficiaryRows');
    const lastUpdated = document.getElementById('lastUpdated');
    const recordInfo = document.getElementById('recordInfo');
    const paginationControls = document.getElementById('paginationControls');
    const importFile = document.getElementById('importFile');
    const importResult = document.getElementById('importResult');
    const sheetCard = document.getElementById('sheetCard');

    let beneficiaries = [];
    let currentPage = 1;
    let selectedImportFile = null;
    let isLoading = false;
    let importTimer = null;

    function escapeHTML(value) {
        if (value === null || value === undefined) return '';

        return String(value)
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#039;');
    }

    function showSystemToast(message, type = 'success') {
        const toast = document.getElementById('systemToast');
        const toastIcon = document.getElementById('toastIcon');
        const toastMessage = document.getElementById('toastMessage');

        if (!toast || !toastIcon || !toastMessage) return;

        toast.classList.remove('success', 'error', 'show');
        toast.classList.add(type);

        toastIcon.textContent = type === 'error' ? 'error' : 'check_circle';
        toastMessage.textContent = message;

        toast.classList.add('show');

        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    function checkUrlToast() {
        const toastParams = new URLSearchParams(window.location.search);
        const toastType = toastParams.get('toast_type');
        const toastMsg = toastParams.get('toast_msg');

        if (toastMsg) {
            showSystemToast(toastMsg, toastType || 'success');

            toastParams.delete('toast_type');
            toastParams.delete('toast_msg');

            const cleanUrl =
                window.location.pathname +
                (toastParams.toString() ? '?' + toastParams.toString() : '');

            window.history.replaceState({}, document.title, cleanUrl);
        }
    }

    function displayStatus(status) {
        if (status === 'WAITING_STEP_2') return 'Waiting Step 2';
        if (status === 'CALLED_STEP_2') return 'Called Step 2';
        if (status === 'WAITING_STEP_3') return 'Waiting Step 3';
        if (status === 'CALLED_STEP_3') return 'Called Step 3';
        if (status === 'PAID') return 'Paid';
        if (status === 'CANCELLED') return 'Cancelled';
        return 'No Queue';
    }

    function statusClass(status) {
        if (status === 'WAITING_STEP_2') return 'status-step-2';
        if (status === 'CALLED_STEP_2') return 'status-called-2';
        if (status === 'WAITING_STEP_3') return 'status-step-3';
        if (status === 'CALLED_STEP_3') return 'status-called-3';
        if (status === 'PAID') return 'status-paid';
        if (status === 'CANCELLED') return 'status-cancelled';
        return 'status-none';
    }

    function getFullName(row) {
        const middle = row.middle_name ? ' ' + row.middle_name : '';
        const ext = row.ext_name ? ' ' + row.ext_name : '';
        return `${row.last_name || ''}, ${row.first_name || ''}${middle}${ext}`.trim();
    }

    function getCategory(row) {
        if (parseInt(row.is_pwd || row.sms_opt_in || 0) === 1) return 'PWD';
        if (parseInt(row.is_pregnant || 0) === 1) return 'Pregnant';
        if (parseInt(row.age || 0) >= 60) return 'Senior';
        return 'Regular';
    }

    function catClass(cat) {
        if (cat === 'PWD') return 'cat-pwd';
        if (cat === 'Pregnant') return 'cat-pregnant';
        if (cat === 'Senior') return 'cat-senior';
        return 'cat-regular';
    }

    function getFilteredRows() {
        const searchValue = searchInput.value.toLowerCase().trim();
        const typeValue = typeFilter.value;
        const statusValue = statusFilter.value;

        return beneficiaries.filter(row => {
            const hasQueue = row.queue_number && row.queue_number !== '';

            const searchable = [
                row.queue_number,
                row.last_name,
                row.first_name,
                row.middle_name,
                row.ext_name,
                row.barangay,
                row.city_municipality,
                row.lgu,
                row.contact_number,
                row.beneficiary_code,
                row.program_type
            ].join(' ').toLowerCase();

            if (searchValue && !searchable.includes(searchValue)) return false;

            if (typeValue === 'priority' && row.queue_type !== 'priority') return false;
            if (typeValue === 'regular' && row.queue_type !== 'regular') return false;
            if (typeValue === 'none' && hasQueue) return false;

            if (statusValue === 'none' && hasQueue) return false;
            if (statusValue !== 'all' && statusValue !== 'none' && row.workflow_status !== statusValue) return false;

            return true;
        });
    }

    function renderPagination(totalRows, totalPages) {
        if (totalRows === 0) {
            paginationControls.innerHTML = '';
            return;
        }

        paginationControls.innerHTML = `
            <button class="page-btn" onclick="goToPage(1)" ${currentPage === 1 ? 'disabled' : ''}>«</button>
            <button class="page-btn" onclick="goToPage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>‹</button>
            <span class="page-info">Page ${currentPage} of ${totalPages}</span>
            <button class="page-btn" onclick="goToPage(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>›</button>
            <button class="page-btn" onclick="goToPage(${totalPages})" ${currentPage === totalPages ? 'disabled' : ''}>»</button>
        `;
    }

    function renderTable() {
        const filtered = getFilteredRows();
        const perPage = parseInt(rowsPerPage.value, 10);
        const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));

        if (currentPage > totalPages) currentPage = totalPages;

        const startIndex = (currentPage - 1) * perPage;
        const pageRows = filtered.slice(startIndex, startIndex + perPage);

        if (pageRows.length === 0) {
            tableBody.innerHTML = '<tr><td colspan="9" class="empty-state">No beneficiaries found.</td></tr>';
            recordInfo.innerText = `Showing 0 of ${beneficiaries.length} records`;
            renderPagination(0, 1);
            return;
        }

        let html = '';

        pageRows.forEach((row, index) => {
            const hasQueue = row.queue_number && row.queue_number !== '';
            const isPriority = row.queue_type === 'priority';
            const rowClass = isPriority ? 'row-priority' : '';
            const queueNumberClass = isPriority ? 'queue-number priority-queue-number' : 'queue-number';
            const fullName = getFullName(row);
            const actualNumber = startIndex + index + 1;
            const cat = getCategory(row);

            html += `
                <tr class="${rowClass}">
                    <td class="row-number">${actualNumber}</td>

                    <td class="${queueNumberClass}">
                        ${hasQueue ? escapeHTML(row.queue_number) + (isPriority ? '<span class="priority-label">PRIO</span>' : '') : 'Not generated'}
                    </td>

                    <td>
                        <span class="client-name">${escapeHTML(fullName)}</span>
                        <span class="category-badge ${catClass(cat)}">${cat}</span>
                        <span class="muted-small">${escapeHTML(row.beneficiary_code || 'No code')}</span>
                    </td>

                    <td>${escapeHTML(row.barangay || '')}</td>
                    <td>${escapeHTML(row.age || '')}</td>
                    <td>${escapeHTML(row.sex || '')}</td>
                    <td>${escapeHTML(row.lgu || '')}</td>

                    <td>
                        <span class="status-badge ${statusClass(row.workflow_status)}">
                            ${displayStatus(row.workflow_status)}
                        </span>
                    </td>

                    <td>
                        <div class="action-group">
                            <button type="button" class="icon-btn btn-view" title="View Details" onclick="openDetailsModal('${escapeHTML(row.id)}')">
                                <span class="material-icons">visibility</span>
                            </button>

                            <form method="POST" action="../api/generate_regular_qn.php">
                                <input type="hidden" name="beneficiary_id" value="${escapeHTML(row.id)}">
                                <button type="submit" class="icon-btn btn-regular" title="Generate Regular Queue" ${hasQueue ? 'disabled' : ''}>
                                    <span class="material-icons">groups</span>
                                </button>
                            </form>

                            <form method="POST" action="../api/generate_priority_qn.php">
                                <input type="hidden" name="beneficiary_id" value="${escapeHTML(row.id)}">
                                <button type="submit" class="icon-btn btn-priority" title="Generate Priority Queue" ${hasQueue ? 'disabled' : ''}>
                                    <span class="material-icons">priority_high</span>
                                </button>
                            </form>

                            <button type="button" class="icon-btn btn-regenerate" title="Regenerate Queue Type" onclick="openRegenModal('${escapeHTML(row.id)}')" ${!hasQueue ? 'disabled' : ''}>
                                <span class="material-icons">autorenew</span>
                            </button>

                            <form method="POST" action="../api/remove_beneficiary.php">
                                <input type="hidden" name="beneficiary_id" value="${escapeHTML(row.id)}">
                                <input type="hidden" name="redirect" value="../staff/verifier.php">
                                <button type="submit" class="icon-btn btn-remove" title="Remove Beneficiary">
                                    <span class="material-icons">delete</span>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            `;
        });

        tableBody.innerHTML = html;
        recordInfo.innerText = `Showing ${startIndex + 1}-${Math.min(startIndex + perPage, filtered.length)} of ${filtered.length} filtered records (${beneficiaries.length} total)`;
        renderPagination(filtered.length, totalPages);
    }

    async function loadVerifierData() {
        if (isLoading) return;

        isLoading = true;

        try {
            const response = await fetch('../api/verifier_data.php?ts=' + Date.now(), {
                cache: 'no-store'
            });

            const rawText = await response.text();
            let data;

            try {
                data = JSON.parse(rawText);
            } catch (jsonError) {
                console.error('Invalid JSON:', rawText);
                tableBody.innerHTML = '<tr><td colspan="9" class="empty-state">Invalid API response. Check api/verifier_data.php.</td></tr>';
                return;
            }

            if (!data.success) {
                tableBody.innerHTML = `<tr><td colspan="9" class="empty-state">${escapeHTML(data.message || 'Failed to load data.')}</td></tr>`;
                return;
            }

            beneficiaries = data.beneficiaries || [];
            renderTable();
            lastUpdated.innerText = 'Last updated: ' + new Date().toLocaleTimeString();

        } catch (error) {
            console.error(error);
            tableBody.innerHTML = '<tr><td colspan="9" class="empty-state">Failed to connect to verifier data API.</td></tr>';
        } finally {
            isLoading = false;
        }
    }

    function progressHTML(title, percent, detail) {
        percent = Math.max(0, Math.min(100, Math.round(percent)));

        return `
            <div class="progress-title">
                <span>${escapeHTML(title)}</span>
                <span>${percent}%</span>
            </div>

            <div class="progress-track">
                <div class="progress-fill" style="width:${percent}%"></div>
            </div>

            <div style="margin-top:8px;font-size:12px;color:#475569;">
                ${escapeHTML(detail)}
            </div>
        `;
    }

    function showImportResult(html, success = true, keep = false) {
        clearTimeout(importTimer);

        importResult.style.display = 'block';
        importResult.style.borderColor = success ? '#86efac' : '#fecaca';
        importResult.style.background = success ? '#f0fdf4' : '#fef2f2';
        importResult.style.color = success ? '#166534' : '#991b1b';
        importResult.innerHTML = html;

        if (!keep) {
            importTimer = setTimeout(() => {
                importResult.style.display = 'none';
                importResult.innerHTML = '';
            }, 6500);
        }
    }

    function resultHTML(data) {
        const inserted = parseInt(data.inserted || 0, 10);
        const duplicates = parseInt(data.duplicates || 0, 10);
        const failed = parseInt(data.failed || 0, 10);
        const checked = parseInt(data.checked || (inserted + duplicates + failed), 10);

        let html = progressHTML('Import finished', 100, 'Verifier table is refreshing...');

        html += `
            <div class="import-stats">
                <div class="import-stat" style="background:#dcfce7;border:1px solid #86efac;">
                    <b>${inserted}</b><br><span>Imported</span>
                </div>

                <div class="import-stat" style="background:#fef3c7;border:1px solid #fde68a;">
                    <b>${duplicates}</b><br><span>Duplicates</span>
                </div>

                <div class="import-stat" style="background:#fee2e2;border:1px solid #fecaca;">
                    <b>${failed}</b><br><span>Skipped</span>
                </div>

                <div class="import-stat" style="background:#dbeafe;border:1px solid #bfdbfe;">
                    <b>${checked}</b><br><span>Checked</span>
                </div>
            </div>
        `;

        if (data.errors && data.errors.length) {
            html += `
                <div style="margin-top:10px;color:#991b1b;font-size:12px;">
                    <b>Skipped row notes:</b><br>
                    ${data.errors.map(escapeHTML).join('<br>')}
                </div>
            `;
        }

        return html;
    }

    function setImportFile(file) {
        if (!file) return;

        const lower = file.name.toLowerCase();

        if (
            !lower.endsWith('.csv') &&
            !lower.endsWith('.xlsx') &&
            !lower.endsWith('.xls') &&
            !lower.endsWith('.xlsm') &&
            !lower.endsWith('.ods')
        ) {
            showImportResult('Upload CSV or Excel file only: .csv, .xlsx, .xls, .xlsm, .ods', false);
            return;
        }

        selectedImportFile = file;
        uploadImportFile();
    }

    async function uploadImportFile() {
        if (!selectedImportFile) {
            showImportResult('No file selected.', false);
            return;
        }

        let percent = 5;
        let done = false;

        showImportResult(progressHTML('Preparing import', percent, 'Checking selected file...'), true, true);

        const timer = setInterval(() => {
            if (done) return;

            if (percent < 88) {
                percent += 3;
            } else if (percent < 96) {
                percent += 1;
            }

            showImportResult(progressHTML('Importing beneficiaries', percent, 'Uploading, checking duplicates, and saving rows...'), true, true);
        }, 350);

        try {
            const formData = new FormData();
            formData.append('import_file', selectedImportFile);

            const response = await fetch('../api/import_beneficiaries.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            done = true;
            clearInterval(timer);

            if (!data.success) {
                showImportResult(escapeHTML(data.message || 'Import failed.'), false);
                return;
            }

            showImportResult(resultHTML(data), true);
            selectedImportFile = null;
            importFile.value = '';
            currentPage = 1;
            loadVerifierData();

        } catch (error) {
            done = true;
            clearInterval(timer);
            console.error(error);
            showImportResult('Import failed. Please check the file format or server settings.', false);
        }
    }

    function openDetailsModalInternal(id) {
        const row = beneficiaries.find(item => String(item.id) === String(id));

        if (!row) return;

        const birthday = row.birthday_month && row.birthday_day && row.birthday_year
            ? `${row.birthday_month}/${row.birthday_day}/${row.birthday_year}`
            : '';

        const isPwd = parseInt(row.is_pwd || row.sms_opt_in || 0) === 1;
        const isPregnant = parseInt(row.is_pregnant || 0) === 1;
        const isSenior = parseInt(row.age || 0) >= 60;

        const address = [
            row.barangay,
            row.city_municipality,
            row.province,
            row.region
        ].filter(Boolean).join(', ');

        const category = getCategory(row);

        const details = [
            ['Priority Category', category, 'detail-priority'],
            ['PWD Status', isPwd ? 'Yes - Priority' : 'No', isPwd ? 'detail-priority' : ''],
            ['Pregnant Status', isPregnant ? 'Yes - Priority' : 'No', isPregnant ? 'detail-priority' : ''],
            ['Senior Status', isSenior ? 'Yes - Priority' : 'No', isSenior ? 'detail-priority' : ''],
            ['Beneficiary Code', row.beneficiary_code],
            ['Queue Number', row.queue_number || 'Not generated'],
            ['Queue Type', row.queue_type || 'None'],
            ['Status', displayStatus(row.workflow_status)],
            ['Full Name', getFullName(row)],
            ['Birthday', birthday],
            ['Age', row.age],
            ['Sex', row.sex],
            ['Contact Number', row.contact_number],
            ['Household ID', row.household_id],
            ['Program Type', row.program_type],
            ['Region', row.region],
            ['Province', row.province],
            ['City/Municipality', row.city_municipality],
            ['Barangay', row.barangay],
            ['LGU', row.lgu],
            ['Complete Address', address || '-']
        ];

        document.getElementById('detailsGrid').innerHTML = details.map(item => `
            <div class="detail-item ${item[2] || ''}">
                <span>${escapeHTML(item[0])}</span>
                <strong>${escapeHTML(item[1] || '-')}</strong>
            </div>
        `).join('');

        document.getElementById('detailsModal').style.display = 'flex';
    }

    function closeDetailsModalInternal() {
        document.getElementById('detailsModal').style.display = 'none';
    }

    function openRegenModalInternal(id) {
        document.getElementById('regenRegularBeneficiaryId').value = id;
        document.getElementById('regenPriorityBeneficiaryId').value = id;
        document.getElementById('regenModal').style.display = 'flex';
    }

    function closeRegenModalInternal() {
        document.getElementById('regenModal').style.display = 'none';
    }

    window.goToPage = function(page) {
        const filtered = getFilteredRows();
        const perPage = parseInt(rowsPerPage.value, 10);
        const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));

        currentPage = Math.min(Math.max(1, page), totalPages);
        renderTable();
    };

    window.chooseFile = function() {
        importFile.click();
    };

    window.manualRefresh = function() {
        isLoading = false;
        currentPage = 1;
        loadVerifierData();
    };

    window.openDetailsModal = openDetailsModalInternal;
    window.closeDetailsModal = closeDetailsModalInternal;
    window.openRegenModal = openRegenModalInternal;
    window.closeRegenModal = closeRegenModalInternal;

    document.getElementById('regenModal').addEventListener('click', function(event) {
        if (event.target === this) {
            closeRegenModalInternal();
        }
    });

    importFile.addEventListener('change', () => {
        setImportFile(importFile.files[0]);
    });

    document.addEventListener('dragover', e => {
        e.preventDefault();
        sheetCard.classList.add('drop-hint');
    });

    document.addEventListener('dragleave', e => {
        if (!e.relatedTarget) {
            sheetCard.classList.remove('drop-hint');
        }
    });

    document.addEventListener('drop', e => {
        e.preventDefault();
        sheetCard.classList.remove('drop-hint');

        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            setImportFile(e.dataTransfer.files[0]);
        }
    });

    [searchInput, typeFilter, statusFilter, rowsPerPage].forEach(element => {
        element.addEventListener('input', () => {
            currentPage = 1;
            renderTable();
        });

        element.addEventListener('change', () => {
            currentPage = 1;
            renderTable();
        });
    });

    document.getElementById('detailsModal').addEventListener('click', function(event) {
        if (event.target === this) {
            closeDetailsModalInternal();
        }
    });

    checkUrlToast();
    loadVerifierData();
})();
</script>

</body>
</html>