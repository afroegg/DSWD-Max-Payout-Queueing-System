<?php
include('../auth/check.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Counter Display</title>

<style>
* {
    box-sizing: border-box;
}

html,
body {
    margin: 0;
    width: 100%;
    height: 100%;
    font-family: Arial, sans-serif;
    background: #f2f5f9;
    color: #111827;
    overflow: hidden;
}

.display {
    height: 100vh;
    display: grid;
    grid-template-rows: 1fr 46px;
}

.boards {
    display: grid;
    grid-template-columns: 1fr 1fr;
    height: 100%;
    min-height: 0;
}

.panel {
    padding: 34px 32px 20px;
    min-width: 0;
    overflow: hidden;
}

.panel:first-child {
    border-right: 3px solid #111827;
}

.title {
    font-size: 42px;
    letter-spacing: 12px;
    font-weight: 1000;
    margin: 6px 0 54px;
    text-transform: uppercase;
}

.title.payout {
    letter-spacing: 8px;
}

.heads {
    display: grid;
    grid-template-columns: 1fr 190px;
    gap: 18px;
    font-size: 28px;
    font-weight: 1000;
    letter-spacing: 3px;
    margin-bottom: 14px;
}

.rule {
    height: 5px;
    background: #111827;
    margin-bottom: 36px;
}

.queue-list {
    min-height: 340px;
}

.row {
    display: grid;
    grid-template-columns: 1fr 190px;
    gap: 18px;
    align-items: center;
    padding: 10px 0 28px;
    margin-bottom: 20px;
    border-bottom: 1px solid #d9dee8;
}

.row.new-flash {
    animation: flashRow 1.2s ease-in-out 2;
}

@keyframes flashRow {
    0% {
        background: #fef3c7;
    }

    100% {
        background: transparent;
    }
}

.qnum {
    font-size: 56px;
    line-height: 1;
    font-weight: 1000;
    color: #0b2e83;
    letter-spacing: 2px;
}

.cnum {
    font-size: 44px;
    line-height: 1;
    font-weight: 1000;
    color: #b91c1c;
    text-align: center;
}

.empty {
    height: 330px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 36px;
    font-weight: 1000;
    color: #9ca3af;
    letter-spacing: 3px;
}

.footer {
    background: #0b2e83;
    color: white;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 26px;
    font-size: 18px;
    font-weight: 1000;
    letter-spacing: 1px;
}

.footer span:last-child {
    font-size: 17px;
}

.voice-btn {
    position: fixed;
    top: 16px;
    right: 16px;
    z-index: 20000;
    border: 0;
    border-radius: 999px;
    background: #16a34a;
    color: white;
    font-weight: 1000;
    padding: 12px 18px;
    cursor: pointer;
    box-shadow: 0 10px 25px rgba(15,23,42,.22);
}

.voice-btn.off {
    background: #64748b;
}

.call-popup {
    position: fixed;
    inset: 0;
    background: rgba(15,23,42,.68);
    z-index: 9999;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 28px;
}

.popup-card {
    width: 820px;
    max-width: 96%;
    background: white;
    border-radius: 28px;
    padding: 42px 36px;
    text-align: center;
    box-shadow: 0 22px 65px rgba(0,0,0,.38);
    border: 8px solid #0b2e83;
    animation: popIn .2s ease-out;
}

.popup-card.payout {
    border-color: #b91c1c;
}

@keyframes popIn {
    from {
        transform: scale(.92);
        opacity: 0;
    }

    to {
        transform: scale(1);
        opacity: 1;
    }
}

.popup-label {
    font-size: 24px;
    font-weight: 1000;
    letter-spacing: 5px;
    text-transform: uppercase;
    color: #475569;
}

.popup-queue {
    font-size: 92px;
    font-weight: 1000;
    color: #0b2e83;
    line-height: 1;
    margin: 24px 0 16px;
    letter-spacing: 4px;
}

.popup-card.payout .popup-queue {
    color: #b91c1c;
}

.popup-counter {
    font-size: 52px;
    font-weight: 1000;
    color: #111827;
    margin-top: 10px;
}

.popup-section {
    font-size: 26px;
    font-weight: 1000;
    color: #64748b;
    margin-top: 8px;
    text-transform: uppercase;
    letter-spacing: 3px;
}

.popup-note {
    margin-top: 22px;
    color: #64748b;
    font-size: 16px;
    font-weight: 800;
}

@media(max-width:1000px) {
    .title {
        font-size: 30px;
        letter-spacing: 6px;
    }

    .heads {
        font-size: 20px;
        grid-template-columns: 1fr 120px;
    }

    .row {
        grid-template-columns: 1fr 120px;
    }

    .qnum {
        font-size: 38px;
    }

    .cnum {
        font-size: 32px;
    }

    .panel {
        padding: 24px 18px;
    }

    .footer {
        font-size: 14px;
    }

    .popup-queue {
        font-size: 58px;
    }

    .popup-counter {
        font-size: 38px;
    }
}
</style>
</head>

<body>

<button id="voiceBtn" class="voice-btn off" onclick="enableVoice()">
    Enable Voice
</button>

<div class="display">
    <div class="boards">
        <section class="panel">
            <h1 class="title">Assessment</h1>
            <div class="heads">
                <div>Queueing Number</div>
                <div>Counter</div>
            </div>
            <div class="rule"></div>

            <div class="queue-list" id="assessmentList">
                <div class="empty">Loading...</div>
            </div>
        </section>

        <section class="panel">
            <h1 class="title payout">Payout / Release</h1>
            <div class="heads">
                <div>Queueing Number</div>
                <div>Counter</div>
            </div>
            <div class="rule"></div>

            <div class="queue-list" id="payoutList">
                <div class="empty">Loading...</div>
            </div>
        </section>
    </div>

    <footer class="footer">
        <span>DSWD Max Payout Queueing and Monitoring System</span>
        <span>Last updated: <b id="clock">--:--:--</b></span>
    </footer>
</div>

<div id="callPopup" class="call-popup">
    <div id="popupCard" class="popup-card">
        <div class="popup-label">Now Calling</div>
        <div id="popupQueue" class="popup-queue">---</div>
        <div id="popupSection" class="popup-section">Assessment</div>
        <div id="popupCounter" class="popup-counter">Counter --</div>
        <div class="popup-note">Please proceed to the assigned counter.</div>
    </div>
</div>

<script>
const assessmentList = document.getElementById('assessmentList');
const payoutList = document.getElementById('payoutList');
const clock = document.getElementById('clock');
const voiceBtn = document.getElementById('voiceBtn');

const callPopup = document.getElementById('callPopup');
const popupCard = document.getElementById('popupCard');
const popupQueue = document.getElementById('popupQueue');
const popupSection = document.getElementById('popupSection');
const popupCounter = document.getElementById('popupCounter');

let seenCalls = new Set();
let firstLoad = true;
let popupTimer = null;
let voiceEnabled = false;
let currentUtterance = null;

function escapeHTML(value) {
    if (value === null || value === undefined) return '';

    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function tick() {
    clock.textContent = new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}

function renderRows(container, rows) {
    if (!rows || rows.length === 0) {
        container.innerHTML = '<div class="empty">No Active Queue</div>';
        return;
    }

    container.innerHTML = rows.map(row => {
        const key = makeCallKey(row);

        return `
            <div class="row" data-call-key="${escapeHTML(key)}">
                <div class="qnum">${escapeHTML(row.queue_number || '---')}</div>
                <div class="cnum">${escapeHTML(row.counter_number || '--')}</div>
            </div>
        `;
    }).join('');
}

function makeCallKey(row) {
    return `${row.section}_${row.id}_${row.queue_number}_${row.counter_number}_${row.called_at}`;
}

function queueNumberForSpeech(queueNumber) {
    if (!queueNumber) return '';

    return String(queueNumber)
        .replaceAll('-', ' ')
        .replace(/([A-Za-z]+)/g, '$1 ')
        .replace(/\s+/g, ' ')
        .trim();
}

function speakCall(row) {
    if (!voiceEnabled || !('speechSynthesis' in window)) return;

    const sectionName = row.section === 'payout' ? 'Payout' : 'Assessment';
    const queueText = queueNumberForSpeech(row.queue_number);
    const counter = row.counter_number || '';

    const message = `Queue number ${queueText}, please proceed to ${sectionName} counter ${counter}.`;

    try {
        window.speechSynthesis.cancel();

        currentUtterance = new SpeechSynthesisUtterance(message);
        currentUtterance.lang = 'en-US';
        currentUtterance.rate = 0.86;
        currentUtterance.pitch = 1;
        currentUtterance.volume = 1;

        window.speechSynthesis.speak(currentUtterance);

        setTimeout(() => {
            const repeat = new SpeechSynthesisUtterance(message);
            repeat.lang = 'en-US';
            repeat.rate = 0.86;
            repeat.pitch = 1;
            repeat.volume = 1;
            window.speechSynthesis.speak(repeat);
        }, 2800);

    } catch (e) {
        console.error(e);
    }
}

function showPopup(row) {
    clearTimeout(popupTimer);

    const isPayout = row.section === 'payout';
    const sectionName = isPayout ? 'Payout / Release' : 'Assessment';

    popupCard.className = isPayout ? 'popup-card payout' : 'popup-card';

    popupQueue.textContent = row.queue_number || '---';
    popupSection.textContent = sectionName;
    popupCounter.textContent = 'Counter ' + (row.counter_number || '--');

    callPopup.style.display = 'flex';

    popupTimer = setTimeout(() => {
        callPopup.style.display = 'none';
    }, 6500);

    speakCall(row);
}

function flashNewRow(row) {
    const key = makeCallKey(row);

    setTimeout(() => {
        const el = document.querySelector(`[data-call-key="${CSS.escape(key)}"]`);

        if (el) {
            el.classList.add('new-flash');

            setTimeout(() => {
                el.classList.remove('new-flash');
            }, 2600);
        }
    }, 80);
}

function detectNewCalls(rows) {
    rows.forEach(row => {
        const key = makeCallKey(row);

        if (firstLoad) {
            seenCalls.add(key);
            return;
        }

        if (!seenCalls.has(key)) {
            seenCalls.add(key);
            showPopup(row);
            flashNewRow(row);
        }
    });
}

async function loadDisplayData() {
    try {
        const response = await fetch('../api/counter_display_data.php?ts=' + Date.now(), {
            cache: 'no-store'
        });

        const raw = await response.text();
        let data;

        try {
            data = JSON.parse(raw);
        } catch (e) {
            console.error('Invalid counter display API response:', raw);
            return;
        }

        if (!data.success) {
            console.error(data.message || 'Counter display API failed.');
            return;
        }

        const assessment = data.assessment || [];
        const payout = data.payout || [];

        renderRows(assessmentList, assessment);
        renderRows(payoutList, payout);

        const allRows = [...assessment, ...payout]
            .sort((a, b) => {
                const da = new Date(a.called_at || 0).getTime();
                const db = new Date(b.called_at || 0).getTime();
                return da - db;
            });

        detectNewCalls(allRows);

        if (firstLoad) {
            firstLoad = false;
        }

    } catch (e) {
        console.error(e);
    }
}

function enableVoice() {
    voiceEnabled = true;

    voiceBtn.style.display = 'none';

    if ('speechSynthesis' in window) {
        const test = new SpeechSynthesisUtterance('Voice enabled.');
        test.lang = 'en-US';
        test.rate = 0.9;
        window.speechSynthesis.speak(test);
    }
}

callPopup.addEventListener('click', function(event) {
    if (event.target === callPopup) {
        callPopup.style.display = 'none';
    }
});

tick();
setInterval(tick, 1000);

loadDisplayData();
setInterval(loadDisplayData, 2000);
</script>

</body>
</html>