<?php
include('../auth/check.php');
include('../config/db.php');

$queue_id = intval($_GET['queue_id'] ?? 0);

if ($queue_id <= 0) {
    header('Location: assessment_screen.php');
    exit;
}

$stmt = $conn->prepare("
    SELECT 
        q.id AS queue_id,
        q.queue_number,
        q.queue_type,
        q.workflow_status,
        q.beneficiary_id,
        b.beneficiary_code,
        b.first_name,
        b.middle_name,
        b.last_name,
        b.ext_name,
        b.contact_number,
        b.birthday_month,
        b.birthday_day,
        b.birthday_year,
        b.age,
        b.sex,
        b.region,
        b.province,
        b.city_municipality,
        b.barangay,
        b.lgu,
        b.national_id,
        b.household_id,
        b.program_type,
        b.sms_opt_in,
        b.is_pregnant
    FROM queue_entries q
    INNER JOIN beneficiaries b ON b.id=q.beneficiary_id
    WHERE q.id=?
    LIMIT 1
");

$stmt->bind_param('i', $queue_id);
$stmt->execute();
$data = $stmt->get_result()->fetch_assoc();

if (!$data) {
    header('Location: assessment_screen.php');
    exit;
}

$stmt = $conn->prepare("
    SELECT * 
    FROM eligibility_forms 
    WHERE queue_entry_id=? OR beneficiary_id=? 
    ORDER BY id DESC 
    LIMIT 1
");

$stmt->bind_param('ii', $queue_id, $data['beneficiary_id']);
$stmt->execute();
$form = $stmt->get_result()->fetch_assoc() ?: [];

$charter = [];

if (!empty($form['remarks'])) {
    $tmp = json_decode($form['remarks'], true);

    if (is_array($tmp)) {
        $charter = $tmp;
    }
}

function h($v) {
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}

function s($f, $k, $v) {
    return (strval($f[$k] ?? '') === strval($v)) ? 'selected' : '';
}

function c($arr, $k, $v) {
    return in_array($v, $arr[$k] ?? [], true) ? 'checked' : '';
}

function selc($arr, $k, $v) {
    return (($arr[$k] ?? '') === $v) ? 'selected' : '';
}

function categoryFromProgram($program, $queueNumber='') {
    $text = strtoupper($program . ' ' . $queueNumber);

    if (str_contains($text, 'FDAS') || str_contains($text, 'FOOD')) {
        return 'Food Assistance';
    }

    if (str_contains($text, 'CRAS') || str_contains($text, 'CASH') || str_contains($text, 'RELIEF')) {
        return 'Cash Relief Assistance';
    }

    if (str_contains($text, 'PRIO')) {
        return 'Priority Assistance';
    }

    return 'Cash Relief Assistance';
}

$is_locked = intval($form['form_locked'] ?? 0) === 1;

$name = trim($data['last_name'] . ', ' . $data['first_name'] . ' ' . $data['middle_name'] . ' ' . $data['ext_name']);
$birthday = intval($data['birthday_month']) . '/' . intval($data['birthday_day']) . '/' . intval($data['birthday_year']);

$isPwd = intval($data['sms_opt_in'] ?? 0) === 1;
$isPregnant = intval($data['is_pregnant'] ?? 0) === 1;
$isSenior = intval($data['age'] ?? 0) >= 60;

$priorityText = $isPwd ? 'PWD Priority' : ($isPregnant ? 'Pregnant Priority' : ($isSenior ? 'Senior Citizen Priority' : 'Regular'));

$completeAddress = trim(
    ($data['barangay'] ?? '') . ', ' .
    ($data['city_municipality'] ?? '') . ', ' .
    ($data['province'] ?? '') . ', ' .
    ($data['region'] ?? ''),
    ', '
);

$program = categoryFromProgram($data['program_type'] ?? '', $data['queue_number'] ?? '');

$common = [
    'Valid ID / Barangay Certification presented',
    'Client information verified',
    'Authorization Letter, if applicable'
];

$requirements = [
    'Food Assistance' => [
        'Barangay Certificate of Residency / Indigency',
        'Proof that client is in need of food assistance',
        'Medical document if admitted / medically related, if applicable'
    ],
    'Cash Relief Assistance' => [
        'Barangay Certificate / Police Report / Blotter / Spot Report',
        'DAFAC / JAPIC / Incident Certification, if applicable',
        'Proof of emergency or crisis situation'
    ],
    'Priority Assistance' => [
        'PWD ID / OSCA ID / Pregnancy proof / Priority proof, if applicable',
        'Actual assistance category to be validated by SWO',
        'Client is endorsed for priority handling'
    ]
];

$checklistItems = array_merge($common, $requirements[$program] ?? $requirements['Cash Relief Assistance']);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>AICS GIS Form</title>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="../assets/style.css">

<style>
body {
    background: #f3f6fb;
}

.wrap {
    padding: 20px;
    flex: 1;
    overflow: auto;
}

.card {
    background: white;
    border: 1px solid #d6dce8;
    border-radius: 14px;
    padding: 20px;
    margin-bottom: 16px;
}

h1 {
    margin: 0;
    color: #111827;
}

.muted {
    color: #6b7280;
    margin: 7px 0 0;
}

.section-title {
    font-weight: 1000;
    color: #0b2e83;
    margin: 4px 0 14px;
    text-transform: uppercase;
    letter-spacing: .5px;
}

.info {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
    margin-top: 16px;
}

.info div {
    background: #f8fafc;
    border: 1px solid #e5e7eb;
    border-radius: 10px;
    padding: 12px;
}

.info span {
    display: block;
    color: #64748b;
    font-size: 11px;
    font-weight: 900;
    text-transform: uppercase;
    margin-bottom: 4px;
}

.info strong {
    color: #111827;
    word-break: break-word;
}

.wide {
    grid-column: span 2;
}

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
}

.field {
    display: flex;
    flex-direction: column;
}

.field label {
    font-size: 13px;
    font-weight: 900;
    color: #374151;
    margin-bottom: 6px;
}

select {
    min-height: 46px;
    padding: 10px 12px;
    border: 1px solid #cbd5e1;
    border-radius: 9px;
    font-size: 14px;
    background: white;
    cursor: pointer;
}

.full {
    grid-column: 1 / -1;
}

.actions {
    display: flex;
    gap: 10px;
    margin-top: 18px;
    flex-wrap: wrap;
}

.btn {
    border: 0;
    text-decoration: none;
    padding: 12px 18px;
    border-radius: 9px;
    font-weight: 900;
    cursor: pointer;
}

.save {
    background: #2563eb;
    color: white;
}

.approve {
    background: #16a34a;
    color: white;
}

.back {
    background: #374151;
    color: white;
}

.lock {
    display: inline-block;
    padding: 8px 12px;
    border-radius: 999px;
    font-weight: 900;
    margin-top: 12px;
}

.locked {
    background: #dcfce7;
    color: #166534;
}

.draft {
    background: #fef3c7;
    color: #92400e;
}

.priority {
    background: #fff7ed !important;
    border-color: #fed7aa !important;
    color: #9a3412 !important;
}

.checkgrid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 8px;
}

.check {
    display: flex;
    gap: 8px;
    align-items: flex-start;
    background: #f8fafc;
    border: 1px solid #e5e7eb;
    border-radius: 9px;
    padding: 10px;
    font-size: 13px;
    cursor: pointer;
    user-select: none;
}

.check:hover {
    background: #eff6ff;
    border-color: #bfdbfe;
}

.check input {
    margin-top: 2px;
    transform: scale(1.15);
}

.category-pill {
    display: inline-block;
    background: #dbeafe;
    color: #1e40af;
    padding: 8px 12px;
    border-radius: 999px;
    font-weight: 1000;
    margin: 0 0 12px;
}

.mini {
    font-size: 12px;
    color: #64748b;
}

.amount-grid {
    display: grid;
    grid-template-columns: repeat(6, 1fr);
    gap: 8px;
}

.choice-radio {
    position: relative;
}

.choice-radio input {
    display: none;
}

.choice-radio span {
    display: block;
    text-align: center;
    padding: 12px 10px;
    border-radius: 10px;
    border: 2px solid #d6dce8;
    background: #f8fafc;
    font-weight: 900;
    cursor: pointer;
}

.choice-radio input:checked + span {
    background: #0b2e83;
    color: white;
    border-color: #0b2e83;
}

@media(max-width: 1000px) {
    .grid,
    .info,
    .checkgrid,
    .amount-grid {
        grid-template-columns: 1fr;
    }

    .wide {
        grid-column: span 1;
    }
}
</style>
</head>

<body>
<div class="app">
<main class="main">
<section class="wrap">

<div class="card">
    <h1>AICS GIS Form</h1>
    <p class="muted">Clickable and dropdown-based assessment form for faster encoding.</p>

    <div class="lock <?php echo $is_locked ? 'locked' : 'draft'; ?>">
        <?php echo $is_locked ? 'Approved and Locked' : 'Draft / Not yet approved'; ?>
    </div>

    <div class="info">
        <div>
            <span>Queue</span>
            <strong><?php echo h($data['queue_number']); ?></strong>
        </div>

        <div>
            <span>Beneficiary Code</span>
            <strong><?php echo h($data['beneficiary_code']); ?></strong>
        </div>

        <div class="wide">
            <span>Client Name</span>
            <strong><?php echo h($name); ?></strong>
        </div>

        <div>
            <span>Birthday</span>
            <strong><?php echo h($birthday); ?></strong>
        </div>

        <div>
            <span>Age / Sex</span>
            <strong><?php echo intval($data['age']); ?> / <?php echo h($data['sex']); ?></strong>
        </div>

        <div>
            <span>Contact Number</span>
            <strong><?php echo h($data['contact_number'] ?: '-'); ?></strong>
        </div>

        <div class="<?php echo ($isPwd || $isPregnant || $isSenior) ? 'priority' : ''; ?>">
            <span>Priority Status</span>
            <strong><?php echo h($priorityText); ?></strong>
        </div>

        <div>
            <span>Assistance Category</span>
            <strong><?php echo h($program); ?></strong>
        </div>

        <div>
            <span>Region</span>
            <strong><?php echo h($data['region']); ?></strong>
        </div>

        <div>
            <span>Province</span>
            <strong><?php echo h($data['province']); ?></strong>
        </div>

        <div>
            <span>City / Municipality</span>
            <strong><?php echo h($data['city_municipality']); ?></strong>
        </div>

        <div class="wide">
            <span>Complete Address</span>
            <strong><?php echo h($completeAddress); ?></strong>
        </div>
    </div>
</div>

<form class="card" method="POST" action="../api/save_eligibility.php">
    <input type="hidden" name="queue_id" value="<?php echo intval($queue_id); ?>">
    <input type="hidden" name="beneficiary_id" value="<?php echo intval($data['beneficiary_id']); ?>">
    <input type="hidden" name="charter[transaction_mode]" value="GIS Form">
    <input type="hidden" name="charter[classification]" value="Simple">
    <input type="hidden" name="charter[transaction_type]" value="G2C - Government to Citizen">

    <h2 class="section-title">GIS Form</h2>

    <span class="category-pill"><?php echo h($program); ?></span>

    <div class="grid">
        <div class="field">
            <label>ID Presented / Certification</label>
            <select name="id_type_presented" <?php echo $is_locked ? 'disabled' : ''; ?> required>
                <option value="">Select</option>
                <option value="PhilSys ID" <?php echo s($form, 'id_type_presented', 'PhilSys ID'); ?>>PhilSys ID</option>
                <option value="PWD ID" <?php echo s($form, 'id_type_presented', 'PWD ID'); ?>>PWD ID</option>
                <option value="OSCA ID" <?php echo s($form, 'id_type_presented', 'OSCA ID'); ?>>OSCA ID</option>
                <option value="Barangay Certification" <?php echo s($form, 'id_type_presented', 'Barangay Certification'); ?>>Barangay Certification</option>
                <option value="Other Valid ID" <?php echo s($form, 'id_type_presented', 'Other Valid ID'); ?>>Other Valid ID</option>
            </select>
        </div>

        <div class="field">
            <label>ID Reference</label>
            <select name="id_reference_note" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <option value="Verified" <?php echo s($form, 'id_reference_note', 'Verified'); ?>>Verified</option>
                <option value="Not Available" <?php echo s($form, 'id_reference_note', 'Not Available'); ?>>Not Available</option>
                <option value="For Follow-up" <?php echo s($form, 'id_reference_note', 'For Follow-up'); ?>>For Follow-up</option>
            </select>
        </div>

        <div class="field">
            <label>Authorization Letter</label>
            <select name="charter[authorization_letter]" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <option value="Not Applicable" <?php echo selc($charter, 'authorization_letter', 'Not Applicable'); ?>>Not Applicable</option>
                <option value="Presented" <?php echo selc($charter, 'authorization_letter', 'Presented'); ?>>Presented</option>
                <option value="Required but Missing" <?php echo selc($charter, 'authorization_letter', 'Required but Missing'); ?>>Required but Missing</option>
            </select>
        </div>

        <div class="field">
            <label>Household Members</label>
            <select name="household_members" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <?php for ($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo $i; ?>" <?php echo s($form, 'household_members', $i); ?>><?php echo $i; ?></option>
                <?php endfor; ?>
                <option value="13" <?php echo s($form, 'household_members', 13); ?>>13+</option>
            </select>
        </div>

        <div class="field">
            <label>Dependents</label>
            <select name="dependents" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <?php for ($i = 0; $i <= 10; $i++): ?>
                    <option value="<?php echo $i; ?>" <?php echo s($form, 'dependents', $i); ?>><?php echo $i; ?></option>
                <?php endfor; ?>
                <option value="11" <?php echo s($form, 'dependents', 11); ?>>11+</option>
            </select>
        </div>

        <div class="field">
            <label>Monthly Income Range</label>
            <select name="monthly_income" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <option value="0" <?php echo s($form, 'monthly_income', '0'); ?>>No Income</option>
                <option value="3000" <?php echo s($form, 'monthly_income', '3000'); ?>>Below ₱5,000</option>
                <option value="7500" <?php echo s($form, 'monthly_income', '7500'); ?>>₱5,000 - ₱10,000</option>
                <option value="12500" <?php echo s($form, 'monthly_income', '12500'); ?>>₱10,001 - ₱15,000</option>
                <option value="20000" <?php echo s($form, 'monthly_income', '20000'); ?>>Above ₱15,000</option>
            </select>
        </div>

        <div class="field">
            <label>Source of Income</label>
            <select name="income_source" <?php echo $is_locked ? 'disabled' : ''; ?> required>
                <option value="BSNS" <?php echo s($form, 'income_source', 'BSNS'); ?>>BSNS</option>
                <option value="SLRY" <?php echo s($form, 'income_source', 'SLRY'); ?>>SLRY</option>
                <option value="NONE" <?php echo s($form, 'income_source', 'NONE'); ?>>NONE</option>
            </select>
        </div>

        <div class="field">
            <label>Client Category</label>
            <select name="beneficiary_type" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <option value="Regular" <?php echo s($form, 'beneficiary_type', 'Regular'); ?>>Regular</option>
                <option value="PWD Priority" <?php echo s($form, 'beneficiary_type', 'PWD Priority'); ?>>PWD Priority</option>
                <option value="Pregnant Priority" <?php echo s($form, 'beneficiary_type', 'Pregnant Priority'); ?>>Pregnant Priority</option>
                <option value="Senior Citizen Priority" <?php echo s($form, 'beneficiary_type', 'Senior Citizen Priority'); ?>>Senior Citizen Priority</option>
            </select>
        </div>

        <div class="field">
            <label>Assistance Requested</label>
            <select name="assistance_reason" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <option value="Food Assistance" <?php echo s($form, 'assistance_reason', 'Food Assistance'); ?>>Food Assistance</option>
                <option value="Cash Relief Assistance" <?php echo s($form, 'assistance_reason', 'Cash Relief Assistance'); ?>>Cash Relief Assistance</option>
                <option value="Priority Assistance" <?php echo s($form, 'assistance_reason', 'Priority Assistance'); ?>>Priority Assistance</option>
            </select>
        </div>

        <div class="field">
            <label>CrIMS / Frequency Check</label>
            <select name="matches_masterlist" <?php echo $is_locked ? 'disabled' : ''; ?> required>
                <option value="Yes" <?php echo s($form, 'matches_masterlist', 'Yes'); ?>>Eligible / No disqualifying record</option>
                <option value="No" <?php echo s($form, 'matches_masterlist', 'No'); ?>>Not verified / Has concern</option>
            </select>
        </div>

        <div class="field">
            <label>Already Received Payout?</label>
            <select name="already_received_payout" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <option value="No" <?php echo s($form, 'already_received_payout', 'No'); ?>>No</option>
                <option value="Yes" <?php echo s($form, 'already_received_payout', 'Yes'); ?>>Yes</option>
            </select>
        </div>

        <div class="field">
            <label>Other Assistance?</label>
            <select name="receiving_other_assistance" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <option value="No" <?php echo s($form, 'receiving_other_assistance', 'No'); ?>>No</option>
                <option value="Yes" <?php echo s($form, 'receiving_other_assistance', 'Yes'); ?>>Yes</option>
            </select>
        </div>

        <div class="field">
            <label>Requirement Status</label>
            <select name="supporting_documents" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <option value="Complete" <?php echo s($form, 'supporting_documents', 'Complete'); ?>>Complete</option>
                <option value="Incomplete" <?php echo s($form, 'supporting_documents', 'Incomplete'); ?>>Incomplete</option>
                <option value="For Follow-up" <?php echo s($form, 'supporting_documents', 'For Follow-up'); ?>>For Follow-up</option>
            </select>
        </div>

        <div class="field">
            <label>Eligibility Status</label>
            <select name="eligibility_status" <?php echo $is_locked ? 'disabled' : ''; ?> required>
                <option value="Eligible" <?php echo s($form, 'eligibility_status', 'Eligible'); ?>>Eligible</option>
                <option value="Not Eligible" <?php echo s($form, 'eligibility_status', 'Not Eligible'); ?>>Not Eligible</option>
                <option value="Pending Review" <?php echo s($form, 'eligibility_status', 'Pending Review'); ?>>Pending Review</option>
            </select>
        </div>

        <div class="field full">
            <label>Approved Amount</label>
            <div class="amount-grid">
                <?php
                $amounts = [0, 1000, 2000, 3000, 5000, 10000];
                $currentAmount = strval($form['approved_cash_amount'] ?? '0');
                foreach ($amounts as $amount):
                ?>
                    <label class="choice-radio">
                        <input type="radio" name="approved_cash_amount" value="<?php echo $amount; ?>" <?php echo $currentAmount == strval($amount) ? 'checked' : ''; ?> <?php echo $is_locked ? 'disabled' : ''; ?>>
                        <span><?php echo $amount == 0 ? 'None' : '₱' . number_format($amount); ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="field full">
            <label>Remarks</label>
            <select name="charter[remarks]" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <option value="Minimal GIS assessment completed." <?php echo selc($charter, 'remarks', 'Minimal GIS assessment completed.'); ?>>Minimal GIS assessment completed.</option>
                <option value="For payout release." <?php echo selc($charter, 'remarks', 'For payout release.'); ?>>For payout release.</option>
                <option value="For follow-up requirements." <?php echo selc($charter, 'remarks', 'For follow-up requirements.'); ?>>For follow-up requirements.</option>
                <option value="Not eligible based on assessment." <?php echo selc($charter, 'remarks', 'Not eligible based on assessment.'); ?>>Not eligible based on assessment.</option>
            </select>
        </div>
    </div>

    <h2 class="section-title" style="margin-top:22px;">Requirements Checklist</h2>

    <p class="mini">Checklist is limited to Food Assistance, Cash Relief Assistance, and Priority validation only.</p>

    <div class="checkgrid">
        <?php foreach ($checklistItems as $item): ?>
            <label class="check">
                <input type="checkbox" name="charter[requirements][]" value="<?php echo h($item); ?>" <?php echo c($charter, 'requirements', $item); ?> <?php echo $is_locked ? 'disabled' : ''; ?>>
                <span><?php echo h($item); ?></span>
            </label>
        <?php endforeach; ?>
    </div>

    <div class="actions">
        <a class="btn back" href="assessment_screen.php">Back</a>

        <?php if (!$is_locked): ?>
            <button class="btn save" name="action" value="save">Save Draft</button>
            <button class="btn approve" name="action" value="approve">Approve / Lock GIS</button>
        <?php endif; ?>
    </div>
</form>

</section>
</main>

<?php include('sidebar.php'); ?>

</div>
</body>
</html>