<?php
include('../auth/check.php');
include('../config/db.php');

$conn->query("
    CREATE TABLE IF NOT EXISTS system_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value VARCHAR(255) NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
");

$conn->query("
    INSERT IGNORE INTO system_settings (setting_key, setting_value)
    VALUES ('counter_assignment_mode', 'automatic')
");

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function getSetting($conn, $key, $default = '') {
    $stmt = $conn->prepare("SELECT setting_value FROM system_settings WHERE setting_key=? LIMIT 1");
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res && $res->num_rows > 0) {
        return $res->fetch_assoc()['setting_value'];
    }

    return $default;
}

$mode = getSetting($conn, 'counter_assignment_mode', 'automatic');
$saved = isset($_GET['saved']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>System Settings</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../assets/style.css">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<style>
* {
    box-sizing: border-box;
}

body {
    background: #f3f6fb;
}

.settings-content {
    padding: 20px;
    flex: 1;
    overflow: auto;
}

.header-card {
    background: linear-gradient(135deg, #0b2e83, #168fcb);
    color: white;
    padding: 22px;
    border-radius: 14px;
    margin-bottom: 16px;
}

.header-card h1 {
    margin: 0;
    font-size: 28px;
}

.header-card p {
    margin: 6px 0 0;
    opacity: .92;
    font-size: 14px;
}

.settings-card {
    background: white;
    border: 1px solid #d6dce8;
    border-radius: 14px;
    padding: 22px;
    max-width: 920px;
    box-shadow: 0 6px 18px rgba(15,23,42,.05);
}

.settings-card h2 {
    margin: 0 0 8px;
    color: #0f172a;
}

.settings-card p {
    margin: 0 0 18px;
    color: #64748b;
    font-size: 14px;
    line-height: 1.5;
}

.option-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 14px;
    margin-bottom: 18px;
}

.option {
    border: 2px solid #d6dce8;
    border-radius: 14px;
    padding: 18px;
    cursor: pointer;
    background: #f8fafc;
    transition: .15s ease;
}

.option:hover {
    border-color: #168fcb;
    background: #eff6ff;
}

.option input {
    display: none;
}

.option.active {
    border-color: #0b2e83;
    background: #eff6ff;
}

.option-title {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 18px;
    font-weight: 900;
    color: #0f172a;
    margin-bottom: 8px;
}

.option-title .material-icons {
    color: #0b2e83;
}

.option-desc {
    color: #64748b;
    font-size: 13px;
    line-height: 1.5;
}

.info-box {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 14px;
    margin-bottom: 18px;
    color: #334155;
    font-size: 14px;
    line-height: 1.6;
}

.save-btn {
    height: 46px;
    border: none;
    border-radius: 10px;
    background: #0b2e83;
    color: white;
    font-weight: 900;
    padding: 0 22px;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.saved {
    background: #dcfce7;
    color: #166534;
    border: 1px solid #86efac;
    border-radius: 10px;
    padding: 12px 14px;
    margin-bottom: 14px;
    font-weight: 900;
    max-width: 920px;
}

@media(max-width: 800px) {
    .option-grid {
        grid-template-columns: 1fr;
    }
}
</style>
</head>

<body>
<div class="app">

<main class="main">
<section class="settings-content">

<div class="header-card">
    <h1>System Settings</h1>
    <p>Configure how assessment and confirmation counters are assigned.</p>
</div>

<?php if ($saved): ?>
    <div class="saved">
        Settings saved successfully.
    </div>
<?php endif; ?>

<form method="POST" action="../api/save_settings.php" class="settings-card">

    <h2>Counter Assignment Mode</h2>
    <p>
        Choose whether the system should automatically assign counters or allow staff to manually select counters before calling a beneficiary.
    </p>

    <div class="info-box">
        <strong>Assessment counters:</strong> Counter 1 to Counter 5 only.<br>
        <strong>Confirmation / Payout counters:</strong> Counter 6 to Counter 10 only.
    </div>

    <div class="option-grid">

        <label class="option <?php echo $mode === 'automatic' ? 'active' : ''; ?>">
            <input type="radio" name="counter_assignment_mode" value="automatic" <?php echo $mode === 'automatic' ? 'checked' : ''; ?>>

            <div class="option-title">
                <span class="material-icons">auto_mode</span>
                Automatic
            </div>

            <div class="option-desc">
                The system automatically assigns the next available counter. Assessment uses Counter 1–5 and Confirmation uses Counter 6–10.
            </div>
        </label>

        <label class="option <?php echo $mode === 'manual' ? 'active' : ''; ?>">
            <input type="radio" name="counter_assignment_mode" value="manual" <?php echo $mode === 'manual' ? 'checked' : ''; ?>>

            <div class="option-title">
                <span class="material-icons">touch_app</span>
                Manual
            </div>

            <div class="option-desc">
                Staff can choose the counter manually before calling the beneficiary. Assessment allows Counter 1–5 and Confirmation allows Counter 6–10.
            </div>
        </label>

    </div>

    <button type="submit" class="save-btn">
        <span class="material-icons">save</span>
        Save Settings
    </button>

</form>

</section>
</main>

<?php include('sidebar.php'); ?>

</div>

<script>
document.querySelectorAll('.option').forEach(option => {
    option.addEventListener('click', function () {
        document.querySelectorAll('.option').forEach(o => o.classList.remove('active'));
        this.classList.add('active');
    });
});
</script>

</body>
</html>